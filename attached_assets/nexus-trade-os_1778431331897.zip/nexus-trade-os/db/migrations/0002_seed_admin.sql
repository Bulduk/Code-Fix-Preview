-- Seed: ilk admin kullanıcı (parola .env'den, bootstrap script'iyle güncellenir)
-- Placeholder hash bcrypt("change-me-immediately") — bootstrap sonrası değiştirilmeli
INSERT INTO users (email, password_hash, role)
VALUES (
  'admin@nexus.local',
  '$2b$12$3w8H0sQ5e0u5mYx3cV9iIu6oQ5mP1bN0kT9wR2sJ4aL6mB8nV0yEa',
  'admin'
)
ON CONFLICT (email) DO NOTHING;
