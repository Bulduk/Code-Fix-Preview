-- Nexus Trade OS — initial schema
-- TimescaleDB 2.17+ on PostgreSQL 16

CREATE EXTENSION IF NOT EXISTS timescaledb;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ── Auth & RBAC ──────────────────────────────────────────────
CREATE TABLE users (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email         text UNIQUE NOT NULL,
  password_hash text NOT NULL,
  totp_secret   text,
  role          text NOT NULL CHECK (role IN ('admin','trader','viewer')),
  is_active     boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  last_login_at timestamptz
);

CREATE TABLE api_tokens (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name        text NOT NULL,
  token_hash  text NOT NULL,
  scopes      text[] NOT NULL DEFAULT '{}',
  expires_at  timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now(),
  revoked_at  timestamptz
);

-- ── Exchanges (UI-managed) ───────────────────────────────────
CREATE TABLE exchange_accounts (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  exchange     text NOT NULL,                    -- ExchangeId
  label        text NOT NULL,
  mode         text NOT NULL CHECK (mode IN ('paper','testnet','live')),
  api_key_enc  bytea NOT NULL,                   -- AES-GCM
  api_secret_enc bytea NOT NULL,
  passphrase_enc bytea,
  is_active    boolean NOT NULL DEFAULT true,
  risk_limits  jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, exchange, label)
);

-- ── Strategies ───────────────────────────────────────────────
CREATE TABLE strategies (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name        text UNIQUE NOT NULL,
  kind        text NOT NULL,                    -- scalping, mm, momentum, ...
  enabled     boolean NOT NULL DEFAULT false,
  params      jsonb NOT NULL DEFAULT '{}'::jsonb,
  allocation  numeric(20,8) NOT NULL DEFAULT 0,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

-- ── Agents ───────────────────────────────────────────────────
CREATE TABLE agents (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name            text UNIQUE NOT NULL,
  provider        text NOT NULL,                -- anthropic, openai, ollama
  model           text NOT NULL,
  system_instruction text NOT NULL DEFAULT '',
  prompt          text NOT NULL DEFAULT '',
  tools           jsonb NOT NULL DEFAULT '[]'::jsonb,   -- OpenAPI defs
  budget_usd      numeric(12,4) NOT NULL DEFAULT 0,
  enabled         boolean NOT NULL DEFAULT false,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

-- ── Audit log (immutable) ────────────────────────────────────
CREATE TABLE audit_log (
  id          bigserial PRIMARY KEY,
  ts          timestamptz NOT NULL DEFAULT now(),
  user_id     uuid REFERENCES users(id),
  action      text NOT NULL,
  target      text,
  details     jsonb NOT NULL DEFAULT '{}'::jsonb,
  ip          inet
);
CREATE INDEX audit_log_ts_idx ON audit_log (ts DESC);

-- ── Time-series (Timescale hypertables) ──────────────────────
CREATE TABLE ticks (
  ts        timestamptz NOT NULL,
  exchange  text NOT NULL,
  symbol    text NOT NULL,
  px        double precision NOT NULL,
  qty       double precision NOT NULL,
  side      text NOT NULL
);
SELECT create_hypertable('ticks','ts', chunk_time_interval => interval '1 day');
CREATE INDEX ticks_sym_ts ON ticks (exchange, symbol, ts DESC);

CREATE TABLE bars (
  ts        timestamptz NOT NULL,
  exchange  text NOT NULL,
  symbol    text NOT NULL,
  tf        text NOT NULL,
  o double precision, h double precision,
  l double precision, c double precision,
  v double precision
);
SELECT create_hypertable('bars','ts', chunk_time_interval => interval '7 days');
CREATE INDEX bars_sym_tf_ts ON bars (exchange, symbol, tf, ts DESC);

CREATE TABLE signals (
  ts          timestamptz NOT NULL,
  id          uuid NOT NULL,
  strategy    text NOT NULL,
  exchange    text NOT NULL,
  symbol      text NOT NULL,
  side        text NOT NULL,
  strength    double precision NOT NULL,
  reason      text,
  meta        jsonb
);
SELECT create_hypertable('signals','ts', chunk_time_interval => interval '7 days');
CREATE INDEX signals_strat_ts ON signals (strategy, ts DESC);

CREATE TABLE orders (
  ts            timestamptz NOT NULL,
  order_id      text NOT NULL,
  client_id     text NOT NULL,
  exchange      text NOT NULL,
  symbol        text NOT NULL,
  side          text NOT NULL,
  type          text NOT NULL,
  qty           double precision NOT NULL,
  px            double precision,
  tif           text NOT NULL,
  status        text NOT NULL,
  filled_qty    double precision NOT NULL DEFAULT 0,
  avg_px        double precision,
  strategy      text
);
SELECT create_hypertable('orders','ts', chunk_time_interval => interval '7 days');
CREATE INDEX orders_oid ON orders (order_id);
CREATE INDEX orders_status_ts ON orders (status, ts DESC);

CREATE TABLE fills (
  ts        timestamptz NOT NULL,
  order_id  text NOT NULL,
  exchange  text NOT NULL,
  symbol    text NOT NULL,
  side      text NOT NULL,
  qty       double precision NOT NULL,
  px        double precision NOT NULL,
  fee       double precision NOT NULL,
  fee_ccy   text NOT NULL
);
SELECT create_hypertable('fills','ts', chunk_time_interval => interval '7 days');
CREATE INDEX fills_oid ON fills (order_id);

CREATE TABLE pnl_snapshots (
  ts          timestamptz NOT NULL,
  account     text NOT NULL,
  equity      double precision NOT NULL,
  realized    double precision NOT NULL,
  unrealized  double precision NOT NULL,
  by_strategy jsonb NOT NULL DEFAULT '{}'::jsonb,
  by_symbol   jsonb NOT NULL DEFAULT '{}'::jsonb
);
SELECT create_hypertable('pnl_snapshots','ts', chunk_time_interval => interval '1 day');
CREATE INDEX pnl_acct_ts ON pnl_snapshots (account, ts DESC);

-- ── Retention policies (UI'dan değiştirilebilir) ─────────────
SELECT add_retention_policy('ticks',    INTERVAL '30 days', if_not_exists => TRUE);
SELECT add_retention_policy('bars',     INTERVAL '365 days', if_not_exists => TRUE);
SELECT add_retention_policy('signals',  INTERVAL '180 days', if_not_exists => TRUE);
SELECT add_retention_policy('orders',   INTERVAL '730 days', if_not_exists => TRUE);
SELECT add_retention_policy('fills',    INTERVAL '730 days', if_not_exists => TRUE);
SELECT add_retention_policy('pnl_snapshots', INTERVAL '730 days', if_not_exists => TRUE);

-- ── Compression (eski veriyi sıkıştır) ───────────────────────
ALTER TABLE ticks SET (timescaledb.compress, timescaledb.compress_segmentby = 'exchange,symbol');
SELECT add_compression_policy('ticks', INTERVAL '2 days', if_not_exists => TRUE);

ALTER TABLE bars SET (timescaledb.compress, timescaledb.compress_segmentby = 'exchange,symbol,tf');
SELECT add_compression_policy('bars', INTERVAL '14 days', if_not_exists => TRUE);
