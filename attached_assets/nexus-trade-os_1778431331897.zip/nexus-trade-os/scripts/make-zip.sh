#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
NAME="nexus-trade-os-$(date +%Y%m%d-%H%M%S).zip"
echo "▶ Paketleniyor: $NAME"
zip -r "$NAME" . \
  -x "node_modules/*" "*/node_modules/*" \
     ".next/*" "*/.next/*" \
     "target/*" "*/target/*" \
     ".venv/*" "*/.venv/*" \
     "*/__pycache__/*" "*.pyc" \
     "ops/.env" "data/" "logs/" \
     ".git/" "*.zip" "*.tar.gz" \
     "*/dist/" "*/.uv/" \
  > /dev/null
echo "✅ $NAME ($(du -h "$NAME" | cut -f1))"
