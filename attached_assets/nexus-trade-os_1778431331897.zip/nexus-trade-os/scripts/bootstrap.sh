#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo "▶ Nexus Trade OS — bootstrap"

# .env oluştur
if [[ ! -f ops/.env ]]; then
  cp ops/.env.example ops/.env
  # Otomatik secret üret
  JWT=$(openssl rand -hex 32)
  ENC=$(openssl rand -base64 32)
  RPW=$(openssl rand -hex 16)
  PPW=$(openssl rand -hex 16)
  GPW=$(openssl rand -hex 12)
  sed -i "s|generate_with_openssl_rand_hex_32|${JWT}|g" ops/.env
  sed -i "s|generate_with_openssl_rand_base64_32|${ENC}|g" ops/.env
  sed -i "s|change_me_redis_pw|${RPW}|g" ops/.env
  sed -i "s|change_me_strong_pw|${PPW}|g" ops/.env
  sed -i "s|change_me_grafana|${GPW}|g" ops/.env
  echo "✅ ops/.env oluşturuldu (secret'lar otomatik üretildi)"
else
  echo "ℹ ops/.env zaten var, atlanıyor"
fi

# Compose
cd ops
docker compose pull
docker compose build
docker compose up -d

echo "⏳ Servislerin sağlıklı olması bekleniyor..."
sleep 10
docker compose ps

echo ""
echo "✅ Bootstrap tamamlandı."
echo "   UI:        http://localhost:${UI_PORT:-3000}"
echo "   Gateway:   http://localhost:${GATEWAY_PORT:-8080}/health"
echo "   Grafana:   http://localhost:${GRAFANA_PORT:-3001}"
echo ""
echo "⚠ İlk admin: admin@nexus.local / change-me-immediately"
echo "  İlk girişte parolayı DEĞİŞTİR."
