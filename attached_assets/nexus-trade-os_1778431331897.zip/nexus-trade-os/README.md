# Nexus Trade OS

Production-grade, multi-exchange trading platform.
Rust-native execution (NautilusTrader) + Python signal engine + Next.js UI.

## Quick Start

```bash
# Ubuntu 24.04, 8GB+ RAM
sudo ./scripts/vps-install.sh
./scripts/bootstrap.sh
```

- **UI**: https://your-domain.com
- **API**: https://your-domain.com/api/health
- **Grafana**: https://your-domain.com:3001

## Features

- **10+ Borsa**: Binance, Bybit, OKX, Coinbase, Kraken, Bitmex, dYdX, Hyperliquid, IBKR, Polymarket
- **3 Mod**: Paper / Testnet / Live (her borsa için ayrı)
- **9 Strateji**: Scalping, Mean Reversion, Momentum, Breakout, Grid, Market Making, DCA, Trend Following, Arbitrage
- **AI Ajanlar**: Anthropic/OpenAI/Ollama + tool ekleme + sistem talimatı
- **Otomatik Rejim**: Piyasa durumuna göre strateji öneren motor
- **PnL**: Canlı takip, CSV/JSON export, retention temizleme
- **Admin**: RBAC, 2FA, audit log, kill switch, hot-reload

## Architecture

| Layer | Stack |
|-------|-------|
| UI | Next.js 15, TypeScript, Tailwind, shadcn, Rust→WASM |
| Gateway | FastAPI + uvloop, JWT, MsgPack WS |
| Execution | NautilusTrader (Rust core, PyO3) |
| Signal Engine | Python 3.12 + Rust pyo3 hot-path |
| Agents | nautilusagents (Rust) + LLM bridge |
| Bus | Redis Streams |
| DB | TimescaleDB 2.17 / PostgreSQL 16 |

## Full Guide

See [KURULUM.md](./KURULUM.md) for complete installation and configuration.

## License

Proprietary.
