import { z } from "zod";
import { encode, decode } from "@msgpack/msgpack";

// ── Enums ─────────────────────────────────────────────────────
export const ExchangeId = z.enum([
  "binance", "bybit", "okx", "coinbase", "kraken",
  "bitmex", "dydx", "hyperliquid", "ibkr", "polymarket",
]);
export type ExchangeId = z.infer<typeof ExchangeId>;

export const TradingMode = z.enum(["paper", "testnet", "live"]);
export type TradingMode = z.infer<typeof TradingMode>;

export const InstrumentType = z.enum([
  "spot", "perp", "futures", "option", "stock", "fx",
]);

export const OrderSide = z.enum(["buy", "sell"]);
export const OrderType = z.enum(["market", "limit", "stop", "stop_limit"]);
export const TimeInForce = z.enum(["gtc", "ioc", "fok", "post_only"]);
export const OrderStatus = z.enum([
  "pending", "submitted", "accepted", "partial", "filled",
  "canceled", "rejected", "expired",
]);

// ── Core events (UI ↔ engine) ─────────────────────────────────
export const Tick = z.object({
  t: z.literal("tick"),
  ex: ExchangeId,
  sym: z.string(),
  px: z.number(),
  qty: z.number(),
  side: OrderSide,
  ts: z.number().int(),     // engine_ts (ns)
  ui_ts: z.number().int().optional(),
});

export const Bar = z.object({
  t: z.literal("bar"),
  ex: ExchangeId,
  sym: z.string(),
  tf: z.string(),           // "1m", "5m", ...
  o: z.number(), h: z.number(), l: z.number(), c: z.number(),
  v: z.number(),
  ts: z.number().int(),
});

export const Signal = z.object({
  t: z.literal("signal"),
  id: z.string().uuid(),
  strategy: z.string(),
  ex: ExchangeId,
  sym: z.string(),
  side: OrderSide,
  strength: z.number().min(0).max(1),
  reason: z.string(),
  meta: z.record(z.unknown()).optional(),
  ts: z.number().int(),
});

export const OrderEvent = z.object({
  t: z.literal("order"),
  id: z.string(),
  client_id: z.string(),
  ex: ExchangeId,
  sym: z.string(),
  side: OrderSide,
  type: OrderType,
  qty: z.number(),
  px: z.number().optional(),
  tif: TimeInForce,
  status: OrderStatus,
  filled_qty: z.number().default(0),
  avg_px: z.number().optional(),
  ts: z.number().int(),
});

export const Fill = z.object({
  t: z.literal("fill"),
  order_id: z.string(),
  ex: ExchangeId,
  sym: z.string(),
  side: OrderSide,
  qty: z.number(),
  px: z.number(),
  fee: z.number(),
  fee_ccy: z.string(),
  ts: z.number().int(),
});

export const Position = z.object({
  t: z.literal("position"),
  ex: ExchangeId,
  sym: z.string(),
  qty: z.number(),
  avg_px: z.number(),
  unrealized: z.number(),
  realized: z.number(),
  ts: z.number().int(),
});

export const PnLSnapshot = z.object({
  t: z.literal("pnl"),
  account: z.string(),
  equity: z.number(),
  realized: z.number(),
  unrealized: z.number(),
  by_strategy: z.record(z.number()),
  by_symbol: z.record(z.number()),
  ts: z.number().int(),
});

export const EngineEvent = z.discriminatedUnion("t", [
  Tick, Bar, Signal, OrderEvent, Fill, Position, PnLSnapshot,
]);
export type EngineEvent = z.infer<typeof EngineEvent>;

// ── Commands (UI → engine) ────────────────────────────────────
export const PlaceOrderCmd = z.object({
  c: z.literal("place_order"),
  ex: ExchangeId,
  sym: z.string(),
  side: OrderSide,
  type: OrderType,
  qty: z.number().positive(),
  px: z.number().positive().optional(),
  tif: TimeInForce.default("gtc"),
  strategy: z.string().optional(),
});

export const CancelOrderCmd = z.object({
  c: z.literal("cancel_order"),
  ex: ExchangeId,
  order_id: z.string(),
});

export const StrategyToggleCmd = z.object({
  c: z.literal("strategy_toggle"),
  strategy: z.string(),
  enabled: z.boolean(),
  params: z.record(z.unknown()).optional(),
});

export const KillSwitchCmd = z.object({
  c: z.literal("kill_switch"),
  scope: z.enum(["all", "exchange", "strategy"]),
  target: z.string().optional(),
});

export const Command = z.discriminatedUnion("c", [
  PlaceOrderCmd, CancelOrderCmd, StrategyToggleCmd, KillSwitchCmd,
]);
export type Command = z.infer<typeof Command>;

// ── MsgPack codec ─────────────────────────────────────────────
export function encodeEvent(e: EngineEvent): Uint8Array {
  return encode(EngineEvent.parse(e));
}
export function decodeEvent(buf: Uint8Array): EngineEvent {
  return EngineEvent.parse(decode(buf));
}
export function encodeCommand(c: Command): Uint8Array {
  return encode(Command.parse(c));
}
export function decodeCommand(buf: Uint8Array): Command {
  return Command.parse(decode(buf));
}
