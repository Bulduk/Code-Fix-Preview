"""Nexus Trade OS — shared event/command schema (Python side).

Mirror of packages/proto/src/index.ts. Keep field names identical.
"""
from __future__ import annotations
from enum import Enum
from typing import Any, Literal
from pydantic import BaseModel, Field
import msgpack

class ExchangeId(str, Enum):
    binance = "binance"; bybit = "bybit"; okx = "okx"
    coinbase = "coinbase"; kraken = "kraken"; bitmex = "bitmex"
    dydx = "dydx"; hyperliquid = "hyperliquid"
    ibkr = "ibkr"; polymarket = "polymarket"

class TradingMode(str, Enum):
    paper = "paper"; testnet = "testnet"; live = "live"

class OrderSide(str, Enum):
    buy = "buy"; sell = "sell"

class OrderType(str, Enum):
    market = "market"; limit = "limit"
    stop = "stop"; stop_limit = "stop_limit"

class TimeInForce(str, Enum):
    gtc = "gtc"; ioc = "ioc"; fok = "fok"; post_only = "post_only"

class OrderStatus(str, Enum):
    pending = "pending"; submitted = "submitted"; accepted = "accepted"
    partial = "partial"; filled = "filled"
    canceled = "canceled"; rejected = "rejected"; expired = "expired"

class Tick(BaseModel):
    t: Literal["tick"] = "tick"
    ex: ExchangeId
    sym: str
    px: float
    qty: float
    side: OrderSide
    ts: int
    ui_ts: int | None = None

class Bar(BaseModel):
    t: Literal["bar"] = "bar"
    ex: ExchangeId; sym: str; tf: str
    o: float; h: float; l: float; c: float; v: float
    ts: int

class Signal(BaseModel):
    t: Literal["signal"] = "signal"
    id: str
    strategy: str
    ex: ExchangeId
    sym: str
    side: OrderSide
    strength: float = Field(ge=0, le=1)
    reason: str
    meta: dict[str, Any] | None = None
    ts: int

class OrderEvent(BaseModel):
    t: Literal["order"] = "order"
    id: str
    client_id: str
    ex: ExchangeId
    sym: str
    side: OrderSide
    type: OrderType
    qty: float
    px: float | None = None
    tif: TimeInForce
    status: OrderStatus
    filled_qty: float = 0.0
    avg_px: float | None = None
    ts: int

class Fill(BaseModel):
    t: Literal["fill"] = "fill"
    order_id: str
    ex: ExchangeId; sym: str; side: OrderSide
    qty: float; px: float
    fee: float; fee_ccy: str
    ts: int

class Position(BaseModel):
    t: Literal["position"] = "position"
    ex: ExchangeId; sym: str
    qty: float; avg_px: float
    unrealized: float; realized: float
    ts: int

class PnLSnapshot(BaseModel):
    t: Literal["pnl"] = "pnl"
    account: str
    equity: float; realized: float; unrealized: float
    by_strategy: dict[str, float]
    by_symbol: dict[str, float]
    ts: int

# Commands
class PlaceOrderCmd(BaseModel):
    c: Literal["place_order"] = "place_order"
    ex: ExchangeId; sym: str
    side: OrderSide; type: OrderType
    qty: float; px: float | None = None
    tif: TimeInForce = TimeInForce.gtc
    strategy: str | None = None

class CancelOrderCmd(BaseModel):
    c: Literal["cancel_order"] = "cancel_order"
    ex: ExchangeId; order_id: str

class StrategyToggleCmd(BaseModel):
    c: Literal["strategy_toggle"] = "strategy_toggle"
    strategy: str; enabled: bool
    params: dict[str, Any] | None = None

class KillSwitchCmd(BaseModel):
    c: Literal["kill_switch"] = "kill_switch"
    scope: Literal["all", "exchange", "strategy"]
    target: str | None = None

def encode_msg(model: BaseModel) -> bytes:
    return msgpack.packb(model.model_dump(mode="json"), use_bin_type=True)

def decode_msg(buf: bytes) -> dict[str, Any]:
    return msgpack.unpackb(buf, raw=False)
