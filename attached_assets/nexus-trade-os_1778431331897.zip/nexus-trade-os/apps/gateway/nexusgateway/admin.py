"""Admin endpoints — users & audit log."""
from fastapi import APIRouter, Depends
from .auth import require_role, current_user
from .db import pool

router = APIRouter(prefix="/api", tags=["admin"])

@router.get("/users")
async def users(user=Depends(require_role("admin"))):
    async with pool().acquire() as c:
        rows = await c.fetch("SELECT id, email, role, is_active, created_at, last_login_at FROM users ORDER BY email")
    return [{"id": str(r["id"]), **{k: r[k] for k in ("email","role","is_active")},
             "created_at": r["created_at"].isoformat() if r["created_at"] else None,
             "last_login_at": r["last_login_at"].isoformat() if r["last_login_at"] else None} for r in rows]

@router.get("/audit")
async def audit_list(limit: int = 200, user=Depends(require_role("admin"))):
    async with pool().acquire() as c:
        rows = await c.fetch(
            "SELECT id, ts, user_id, action, target, details, ip FROM audit_log ORDER BY ts DESC LIMIT $1", limit)
    return [{"id": r["id"], "ts": r["ts"].isoformat(), "user_id": str(r["user_id"]) if r["user_id"] else None,
             "action": r["action"], "target": r["target"], "details": r["details"],
             "ip": str(r["ip"]) if r["ip"] else None} for r in rows]
