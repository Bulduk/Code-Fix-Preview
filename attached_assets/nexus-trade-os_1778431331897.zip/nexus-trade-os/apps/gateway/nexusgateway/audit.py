"""Immutable audit logging."""
import json
from .db import pool

async def audit(user_id: str | None, action: str, *, target: str | None = None,
                details: dict | None = None, ip: str | None = None) -> None:
    async with pool().acquire() as c:
        await c.execute(
            "INSERT INTO audit_log(user_id, action, target, details, ip) VALUES($1,$2,$3,$4,$5)",
            user_id, action, target, json.dumps(details or {}), ip,
        )
