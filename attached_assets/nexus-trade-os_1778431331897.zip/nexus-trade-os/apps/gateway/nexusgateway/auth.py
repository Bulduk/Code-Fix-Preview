"""JWT + TOTP authentication."""
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, EmailStr
from .db import pool
from .security import verify_password, make_jwt, verify_jwt, verify_totp
from .audit import audit

router = APIRouter(prefix="/api/auth", tags=["auth"])
bearer = HTTPBearer(auto_error=False)

class LoginIn(BaseModel):
    email: EmailStr
    password: str
    totp: str | None = None

class LoginOut(BaseModel):
    token: str
    role: str

@router.post("/login", response_model=LoginOut)
async def login(body: LoginIn, req: Request) -> LoginOut:
    async with pool().acquire() as c:
        row = await c.fetchrow(
            "SELECT id, password_hash, role, totp_secret, is_active FROM users WHERE email=$1",
            body.email,
        )
    if not row or not row["is_active"] or not verify_password(body.password, row["password_hash"]):
        raise HTTPException(401, "invalid credentials")
    if row["totp_secret"]:
        if not body.totp or not verify_totp(row["totp_secret"], body.totp):
            raise HTTPException(401, "totp required")
    await audit(str(row["id"]), "auth.login", details={}, ip=req.client.host if req.client else None)
    return LoginOut(token=make_jwt(str(row["id"]), row["role"]), role=row["role"])

async def current_user(creds: HTTPAuthorizationCredentials | None = Depends(bearer)) -> dict:
    if not creds:
        raise HTTPException(401, "missing token")
    try:
        return verify_jwt(creds.credentials)
    except Exception:
        raise HTTPException(401, "invalid token")

def require_role(roles: str):
    async def dep(user: dict = Depends(current_user)) -> dict:
        if user.get("role") not in roles:
            raise HTTPException(403, "forbidden")
        return user
    return dep
