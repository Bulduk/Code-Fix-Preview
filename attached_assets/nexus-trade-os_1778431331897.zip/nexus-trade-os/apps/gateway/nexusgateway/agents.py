"""Agent CRUD + invoke endpoint."""
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from typing import Any
import json, msgpack
from .auth import current_user, require_role
from .db import pool
from .redisbus import client, S_COMMANDS
from .audit import audit

router = APIRouter(prefix="/api/agents", tags=["agents"])

class AgentIn(BaseModel):
    name: str
    provider: str          # anthropic | openai | ollama
    model: str
    system_instruction: str = ""
    prompt: str = ""
    tools: list[dict] = []
    budget_usd: float = 0
    enabled: bool = False

class AgentInvoke(BaseModel):
    message: str

@router.get("")
async def list_agents(user=Depends(current_user)):
    async with pool().acquire() as c:
        rows = await c.fetch("SELECT id, name, provider, model, enabled, budget_usd FROM agents ORDER BY name")
    return [{"id": str(r["id"]), **{k: r[k] for k in ("name","provider","model","enabled","budget_usd")}} for r in rows]

@router.post("")
async def create_agent(body: AgentIn, user=Depends(require_role("admin"))):
    async with pool().acquire() as c:
        row = await c.fetchrow(
            "INSERT INTO agents(name, provider, model, system_instruction, prompt, tools, budget_usd, enabled) "
            "VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id",
            body.name, body.provider, body.model, body.system_instruction,
            body.prompt, json.dumps(body.tools), body.budget_usd, body.enabled)
    await audit(user["sub"], "agent.create", target=body.name)
    return {"id": str(row["id"])}

@router.put("/{aid}")
async def update_agent(aid: str, body: AgentIn, user=Depends(require_role("admin"))):
    async with pool().acquire() as c:
        await c.execute(
            "UPDATE agents SET name=$2, provider=$3, model=$4, system_instruction=$5, "
            "prompt=$6, tools=$7, budget_usd=$8, enabled=$9, updated_at=now() WHERE id=$1",
            aid, body.name, body.provider, body.model, body.system_instruction,
            body.prompt, json.dumps(body.tools), body.budget_usd, body.enabled)
    await audit(user["sub"], "agent.update", target=aid)
    return {"ok": True}

@router.delete("/{aid}")
async def delete_agent(aid: str, user=Depends(require_role("admin"))):
    async with pool().acquire() as c:
        await c.execute("DELETE FROM agents WHERE id=$1", aid)
    await audit(user["sub"], "agent.delete", target=aid)
    return {"ok": True}

@router.post("/{aid}/invoke")
async def invoke_agent(aid: str, body: AgentInvoke, user=Depends(current_user)):
    cmd = {"c": "agent.invoke", "agent_id": aid, "message": body.message,
           "user": user["sub"], "role": user["role"]}
    await client().xadd(S_COMMANDS, {b"d": msgpack.packb(cmd)},
                        maxlen=10000, approximate=True)
    await audit(user["sub"], "agent.invoke", target=aid)
    return {"ok": True}
