"""Exchange account CRUD — keys stored AES-GCM encrypted."""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from .auth import current_user, require_role
from .db import pool
from .security import encrypt
from .audit import audit

router = APIRouter(prefix="/api/exchanges", tags=["exchanges"])

class ExchangeIn(BaseModel):
    exchange: str
    label: str
    mode: str            # paper | testnet | live
    api_key: str
    api_secret: str
    passphrase: str | None = None
    risk_limits: dict = {}

class ExchangeOut(BaseModel):
    id: str
    exchange: str
    label: str
    mode: str
    is_active: bool
    risk_limits: dict

@router.get("", response_model=list[ExchangeOut])
async def list_accounts(user: dict = Depends(current_user)):
    async with pool().acquire() as c:
        rows = await c.fetch(
            "SELECT id, exchange, label, mode, is_active, risk_limits FROM exchange_accounts "
            "WHERE user_id=$1 ORDER BY created_at DESC", user["sub"],
        )
    return [{"id": str(r["id"]), **{k: r[k] for k in
            ("exchange","label","mode","is_active","risk_limits")}} for r in rows]

@router.post("", response_model=ExchangeOut)
async def create_account(body: ExchangeIn, user: dict = Depends(require_role("admin,trader"))):
    if body.mode not in ("paper","testnet","live"):
        raise HTTPException(400, "invalid mode")
    async with pool().acquire() as c:
        row = await c.fetchrow(
            "INSERT INTO exchange_accounts(user_id, exchange, label, mode, api_key_enc, api_secret_enc, "
            "passphrase_enc, risk_limits) VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id",
            user["sub"], body.exchange, body.label, body.mode,
            encrypt(body.api_key), encrypt(body.api_secret),
            encrypt(body.passphrase) if body.passphrase else None,
            body.risk_limits,
        )
    await audit(user["sub"], "exchange.create",
                target=f"{body.exchange}:{body.label}", details={"mode": body.mode})
    return ExchangeOut(id=str(row["id"]), exchange=body.exchange, label=body.label,
                       mode=body.mode, is_active=True, risk_limits=body.risk_limits)

@router.delete("/{acct_id}")
async def delete_account(acct_id: str, user: dict = Depends(require_role("admin"))):
    async with pool().acquire() as c:
        await c.execute("DELETE FROM exchange_accounts WHERE id=$1 AND user_id=$2",
                        acct_id, user["sub"])
    await audit(user["sub"], "exchange.delete", target=acct_id)
    return {"ok": True}
