"""Gateway entry point — uvicorn with uvloop."""
import uvicorn
from .config import settings

def main() -> None:
    uvicorn.run(
        "nexusgateway.app:app",
        host="0.0.0.0",
        port=settings.gateway_port,
        workers=settings.gateway_workers,
        loop="uvloop",
        http="httptools",
        ws="websockets",
        log_level="info",
        access_log=False,
    )

if __name__ == "__main__":
    main()
