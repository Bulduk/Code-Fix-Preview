"""PnL snapshots + export + purge."""
from fastapi import APIRouter, Depends, Query, HTTPException
from fastapi.responses import StreamingResponse
import io, csv, json
from datetime import datetime
from .auth import current_user, require_role
from .db import pool
from .audit import audit

router = APIRouter(prefix="/api/pnl", tags=["pnl"])

@router.get("/snapshots")
async def snapshots(
    account: str = "default",
    since: datetime | None = None,
    until: datetime | None = None,
    limit: int = Query(1000, le=10000),
    user=Depends(current_user),
):
    q = "SELECT ts, equity, realized, unrealized, by_strategy, by_symbol FROM pnl_snapshots WHERE account=$1"
    args: list = [account]
    if since: q += f" AND ts >= ${len(args)+1}"; args.append(since)
    if until: q += f" AND ts <= ${len(args)+1}"; args.append(until)
    q += f" ORDER BY ts DESC LIMIT ${len(args)+1}"; args.append(limit)
    async with pool().acquire() as c:
        rows = await c.fetch(q, *args)
    return [dict(r) for r in rows]

@router.get("/export")
async def export(
    fmt: str = Query("csv", regex="^(csv|json)$"),
    account: str = "default",
    user=Depends(current_user),
):
    async with pool().acquire() as c:
        rows = await c.fetch(
            "SELECT ts, equity, realized, unrealized, by_strategy, by_symbol "
            "FROM pnl_snapshots WHERE account=$1 ORDER BY ts", account)
    if fmt == "json":
        body = json.dumps([{**dict(r), "ts": r["ts"].isoformat()} for r in rows], default=str)
        return StreamingResponse(io.BytesIO(body.encode()),
            media_type="application/json",
            headers={"Content-Disposition": f'attachment; filename="pnl_{account}.json"'})
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["ts","equity","realized","unrealized","by_strategy","by_symbol"])
    for r in rows:
        w.writerow([r["ts"].isoformat(), r["equity"], r["realized"], r["unrealized"],
                    json.dumps(r["by_strategy"]), json.dumps(r["by_symbol"])])
    return StreamingResponse(io.BytesIO(buf.getvalue().encode()),
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="pnl_{account}.csv"'})

@router.delete("/purge")
async def purge(
    account: str,
    before: datetime,
    user=Depends(require_role("admin")),
):
    async with pool().acquire() as c:
        n = await c.execute(
            "DELETE FROM pnl_snapshots WHERE account=$1 AND ts < $2", account, before)
    await audit(user["sub"], "pnl.purge",
                target=account, details={"before": before.isoformat()})
    return {"ok": True, "deleted": n}
