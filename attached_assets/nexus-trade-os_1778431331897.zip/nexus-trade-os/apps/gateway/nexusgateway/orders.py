"""Order REST endpoint → Redis Stream."""
from fastapi import APIRouter, Depends
import msgpack
from .auth import current_user
from .redisbus import client, S_COMMANDS

router = APIRouter(prefix="/api", tags=["orders"])

@router.post("/orders")
async def place(body: dict, user=Depends(current_user)):
    cmd = {**body, "user": user["sub"], "role": user["role"]}
    await client().xadd(S_COMMANDS, {b"d": msgpack.packb(cmd)},
                        maxlen=10000, approximate=True)
    return {"ok": True}
