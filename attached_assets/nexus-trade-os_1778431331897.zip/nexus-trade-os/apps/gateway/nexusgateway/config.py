from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    gateway_port: int = 8080
    gateway_workers: int = 2

    database_url: str
    redis_url: str

    jwt_secret: str
    jwt_alg: str = "HS256"
    jwt_ttl_min: int = 60
    encryption_key: str            # base64, 32 bytes for AES-GCM
    cors_origins: str = "http://localhost:3000"

settings = Settings()  # type: ignore[call-arg]
