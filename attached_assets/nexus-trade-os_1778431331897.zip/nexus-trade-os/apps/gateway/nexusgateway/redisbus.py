import redis.asyncio as redis
from .config import settings

_client: redis.Redis | None = None

async def init_redis() -> None:
    global _client
    _client = redis.from_url(settings.redis_url, decode_responses=False)
    await _client.ping()

async def close_redis() -> None:
    if _client:
        await _client.aclose()

def client() -> redis.Redis:
    assert _client is not None
    return _client

# Stream keys
S_EVENTS = "nexus:events"     # engine → UI broadcast
S_COMMANDS = "nexus:commands"   # UI → engine
