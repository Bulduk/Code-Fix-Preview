"""Nexus Gateway — FastAPI + uvloop + JWT + MsgPack WS."""
__version__ = "0.1.0"
