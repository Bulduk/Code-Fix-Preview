"""Strategy CRUD — hot-reload parameters."""
from fastapi import APIRouter, Depends
from pydantic import BaseModel
import json
from .auth import current_user, require_role
from .db import pool
from .audit import audit

router = APIRouter(prefix="/api/strategies", tags=["strategies"])

class StrategyIn(BaseModel):
    name: str
    kind: str
    enabled: bool = False
    params: dict = {}
    allocation: float = 0

@router.get("")
async def list_strats(user=Depends(current_user)):
    async with pool().acquire() as c:
        rows = await c.fetch(
            "SELECT id, name, kind, enabled, params, allocation FROM strategies ORDER BY name")
    return [{"id": str(r["id"]), **{k: r[k] for k in
            ("name","kind","enabled","params","allocation")}} for r in rows]

@router.post("")
async def create_strat(body: StrategyIn, user=Depends(require_role("admin,trader"))):
    async with pool().acquire() as c:
        row = await c.fetchrow(
            "INSERT INTO strategies(name, kind, enabled, params, allocation) "
            "VALUES($1,$2,$3,$4,$5) RETURNING id",
            body.name, body.kind, body.enabled, json.dumps(body.params), body.allocation)
    await audit(user["sub"], "strategy.create", target=body.name)
    return {"id": str(row["id"])}

@router.put("/{sid}")
async def update_strat(sid: str, body: StrategyIn, user=Depends(require_role("admin,trader"))):
    async with pool().acquire() as c:
        await c.execute(
            "UPDATE strategies SET name=$2, kind=$3, enabled=$4, params=$5, allocation=$6, "
            "updated_at=now() WHERE id=$1",
            sid, body.name, body.kind, body.enabled, json.dumps(body.params), body.allocation)
    await audit(user["sub"], "strategy.update", target=sid)
    return {"ok": True}

@router.delete("/{sid}")
async def delete_strat(sid: str, user=Depends(require_role("admin"))):
    async with pool().acquire() as c:
        await c.execute("DELETE FROM strategies WHERE id=$1", sid)
    await audit(user["sub"], "strategy.delete", target=sid)
    return {"ok": True}
