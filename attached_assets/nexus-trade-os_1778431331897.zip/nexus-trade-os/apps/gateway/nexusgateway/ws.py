"""WebSocket endpoint — MsgPack binary, JWT auth, fan-out from Redis Streams.

Protocol: nexus.msgpack.v1
- Binary MsgPack frames
- JWT token in query param
- Heartbeat implicit via Redis stream activity
"""
import asyncio, msgpack, time
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query
from .security import verify_jwt
from .redisbus import client, S_EVENTS, S_COMMANDS

router = APIRouter()

@router.websocket("/ws")
async def ws_endpoint(ws: WebSocket, token: str = Query(...)) -> None:
    try:
        user = verify_jwt(token)
    except Exception:
        await ws.close(code=4401); return

    await ws.accept(subprotocol="nexus.msgpack.v1")

    async def reader() -> None:
        """UI → engine: decode MsgPack, push to commands stream."""
        try:
            while True:
                msg = await ws.receive_bytes()
                cmd = msgpack.unpackb(msg, raw=False)
                cmd["user"] = user["sub"]
                cmd["role"] = user["role"]
                cmd["ui_ts"] = int(time.time() * 1e9)
                await client().xadd(S_COMMANDS, {b"d": msgpack.packb(cmd)}, maxlen=10000, approximate=True)
        except WebSocketDisconnect:
            pass

    async def writer() -> None:
        """Engine → UI: tail events stream, broadcast."""
        last_id = "$"
        while True:
            res = await client().xread({S_EVENTS: last_id}, block=1000, count=200)
            if not res:
                continue
            for _, entries in res:
                for eid, fields in entries:
                    last_id = eid
                    payload = fields.get(b"d")
                    if payload:
                        try:
                            await ws.send_bytes(payload)
                        except Exception:
                            return

    rd = asyncio.create_task(reader())
    wr = asyncio.create_task(writer())
    done, pending = await asyncio.wait({rd, wr}, return_when=asyncio.FIRST_COMPLETED)
    for t in pending: t.cancel()
