"""FastAPI application — all routers assembled."""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from prometheus_client import make_asgi_app

from .config import settings
from .db import init_pool, close_pool
from .redisbus import init_redis, close_redis
from .auth import router as auth_router
from .exchanges import router as ex_router
from .agents import router as agents_router
from .strategies import router as strats_router
from .pnl import router as pnl_router
from .orders import router as orders_router
from .admin import router as admin_router
from .ws import router as ws_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_pool(); await init_redis()
    yield
    await close_redis(); await close_pool()

app = FastAPI(title="Nexus Gateway", version="0.1.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in settings.cors_origins.split(",")],
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

app.include_router(auth_router)
app.include_router(ex_router)
app.include_router(agents_router)
app.include_router(strats_router)
app.include_router(pnl_router)
app.include_router(orders_router)
app.include_router(admin_router)
app.include_router(ws_router)
app.mount("/metrics", make_asgi_app())

@app.get("/health")
async def health() -> dict: return {"status": "ok"}
