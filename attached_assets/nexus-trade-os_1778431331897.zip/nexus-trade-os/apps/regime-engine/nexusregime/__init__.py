"""Nexus Regime Engine — market regime detection."""
__version__ = "0.1.0"
