"""Bar event'lerini izler, sembol başına rejim üretir, öneri yayınlar.
UI tarafı bu öneriyi 'apply' butonuyla otomatik uygulayabilir."""
import asyncio, msgpack, time, signal as sig
from collections import defaultdict, deque
import redis.asyncio as redis
from pydantic_settings import BaseSettings, SettingsConfigDict
import structlog
from .detector import detect

log = structlog.get_logger()

class S(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    redis_url: str
s = S()  # type: ignore[call-arg]

S_EVENTS = "nexus:events"

class RegimeEngine:
    def __init__(self) -> None:
        self.rd: redis.Redis | None = None
        self.bars: dict[tuple[str, str], deque] = defaultdict(lambda: deque(maxlen=300))
        self.stop = asyncio.Event()
        self.last_emit: dict[tuple[str, str], int] = {}

    async def start(self) -> None:
        self.rd = redis.from_url(s.redis_url, decode_responses=False)
        await asyncio.gather(self.tail(), self.evaluator())

    async def stop(self) -> None:
        self.stop.set()
        if self.rd: await self.rd.aclose()

    async def publish(self, ev: dict) -> None:
        assert self.rd
        await self.rd.xadd(S_EVENTS, {b"d": msgpack.packb(ev)},
                           maxlen=50000, approximate=True)

    async def tail(self) -> None:
        assert self.rd
        last = "$"
        while not self.stop.is_set():
            res = await self.rd.xread({S_EVENTS: last}, block=1000, count=200)
            if not res: continue
            for _, entries in res:
                for eid, fields in entries:
                    last = eid
                    try:
                        ev = msgpack.unpackb(fields[b"d"], raw=False)
                        if ev.get("t") == "bar":
                            self.bars[(ev["ex"], ev["sym"])].append(ev)
                    except Exception as e:
                        log.error("ev.fail", err=str(e))

    async def evaluator(self) -> None:
        while not self.stop.is_set():
            await asyncio.sleep(15)
            now = int(time.time())
            for (ex, sym), barq in list(self.bars.items()):
                if now - self.last_emit.get((ex, sym), 0) < 60: continue
                bars = list(barq)
                if len(bars) < 50: continue
                r = detect([b["c"] for b in bars], [b["h"] for b in bars],
                           [b["l"] for b in bars], [b["v"] for b in bars])
                if not r: continue
                self.last_emit[(ex, sym)] = now
                await self.publish({
                    "t": "regime", "ex": ex, "sym": sym,
                    "label": r.label, "confidence": r.confidence,
                    "recommended": r.recommended, "metrics": r.metrics,
                    "ts": int(time.time() * 1e9),
                })

async def amain() -> None:
    eng = RegimeEngine()
    loop = asyncio.get_running_loop()
    for sg in (sig.SIGINT, sig.SIGTERM):
        loop.add_signal_handler(sg, lambda: asyncio.create_task(eng.stop()))
    log.info("regime.start")
    try:
        await eng.start()
    finally:
        await eng.stop()

if __name__ == "__main__":
    asyncio.run(amain())
