"""Piyasa rejimi sınıflandırıcı.
Çıktı: (regime, confidence, recommended_strategies)
Rejimler: trend_up, trend_down, range, high_vol, low_vol, breakout, illiquid
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np

@dataclass
class Regime:
    label: str
    confidence: float          # 0..1
    metrics: dict
    recommended: list[str]       # strategy names

def slope(x: np.ndarray) -> float:
    n = len(x)
    if n < 2: return 0.0
    t = np.arange(n, dtype=float)
    return float(np.polyfit(t, x, 1)[0])

def detect(closes: list[float], highs: list[float], lows: list[float],
           volumes: list[float]) -> Regime | None:
    if len(closes) < 50: return None
    c = np.array(closes[-200:]); h = np.array(highs[-200:])
    l = np.array(lows[-200:]);   v = np.array(volumes[-200:])

    ret = np.diff(np.log(c))
    vol = float(ret.std() * np.sqrt(525600))      # 1m bar yıllık vol proxy
    atr = float(np.mean(h - l))
    rng = float((h.max() - l.min()) / c[-1])
    slope_short = slope(c[-30:])
    slope_long  = slope(c[-100:])
    trend = slope_short / (atr + 1e-9)
    liquidity = float(v.mean())

    metrics = {"vol": vol, "atr": atr, "range_pct": rng,
               "slope_short": slope_short, "slope_long": slope_long,
               "trend": trend, "liquidity": liquidity}

    # Rule-based classifier — basit, deterministik, açıklanabilir
    if liquidity < np.percentile(v, 20):
        return Regime("illiquid", 0.7, metrics, ["dca", "marketmaking"])
    if vol > 1.5 and abs(trend) < 0.3:
        return Regime("high_vol", 0.75, metrics,
                      ["meanreversion", "scalping", "grid"])
    if vol < 0.4:
        return Regime("low_vol", 0.7, metrics,
                      ["marketmaking", "grid", "dca"])
    if trend > 0.6 and slope_long > 0:
        return Regime("trend_up", 0.85, metrics,
                      ["momentum", "trendfollowing", "breakout"])
    if trend < -0.6 and slope_long < 0:
        return Regime("trend_down", 0.85, metrics,
                      ["momentum", "trendfollowing", "breakout"])
    if rng < 0.04:
        return Regime("range", 0.7, metrics,
                      ["meanreversion", "grid", "marketmaking"])
    if c[-1] >= h[-30:].max() * 0.999:
        return Regime("breakout", 0.7, metrics, ["breakout", "momentum"])
    return Regime("mixed", 0.5, metrics, ["scalping"])
