import { create } from "zustand";

type S = {
  token: string | null; role: string | null;
  setAuth: (t: string, r: string) => void;
  logout: () => void;

  ticks: Record<string, { px: number; ts: number }>;
  positions: Record<string, any>;
  pnl: { equity: number; realized: number; unrealized: number } | null;
  signals: any[];
  applyEvent: (ev: any) => void;
};

export const useStore = create<S>((set) => ({
  token: typeof window !== "undefined" ? localStorage.getItem("tok") : null,
  role: typeof window !== "undefined" ? localStorage.getItem("role") : null,
  setAuth: (t, r) => { localStorage.setItem("tok", t); localStorage.setItem("role", r); set({ token: t, role: r }); },
  logout: () => { localStorage.removeItem("tok"); localStorage.removeItem("role"); set({ token: null, role: null }); },

  ticks: {}, positions: {}, pnl: null, signals: [],
  applyEvent: (ev) => set((s) => {
    if (ev.t === "tick")     return { ticks: { ...s.ticks, [`${ev.ex}:${ev.sym}`]: { px: ev.px, ts: ev.ts } } };
    if (ev.t === "position") return { positions: { ...s.positions, [`${ev.ex}:${ev.sym}`]: ev } };
    if (ev.t === "pnl")      return { pnl: { equity: ev.equity, realized: ev.realized, unrealized: ev.unrealized } };
    if (ev.t === "signal")   return { signals: [ev, ...s.signals].slice(0, 200) };
    return s;
  }),
}));
