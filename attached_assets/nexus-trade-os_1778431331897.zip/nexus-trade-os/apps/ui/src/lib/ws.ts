import { decode, encode } from "@msgpack/msgpack";

export type WSEvent = Record<string, any>;
type Listener = (ev: WSEvent) => void;

export class NexusWS {
  private ws: WebSocket | null = null;
  private listeners = new Set<Listener>();
  private retry = 0;
  private url: string;

  constructor(url: string, private token: string) {
    this.url = `${url}?token=${encodeURIComponent(token)}`;
  }

  connect() {
    this.ws = new WebSocket(this.url, "nexus.msgpack.v1");
    this.ws.binaryType = "arraybuffer";
    this.ws.onopen = () => { this.retry = 0; };
    this.ws.onmessage = (e) => {
      try {
        const ev = decode(new Uint8Array(e.data as ArrayBuffer)) as WSEvent;
        this.listeners.forEach((l) => l(ev));
      } catch {}
    };
    this.ws.onclose = () => {
      const ms = Math.min(15000, 500 * 2 ** this.retry++);
      setTimeout(() => this.connect(), ms);
    };
  }

  send(cmd: object) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(encode({ ...cmd, ui_ts: Date.now() * 1000000 }));
    }
  }

  on(l: Listener) { this.listeners.add(l); return () => this.listeners.delete(l); }
  close() { this.ws?.close(); }
}
