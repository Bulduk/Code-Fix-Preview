"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useStore } from "@/lib/store";

export default function Login() {
  const [email, setEmail] = useState("admin@nexus.local");
  const [pw, setPw] = useState("");
  const [totp, setTotp] = useState("");
  const [err, setErr] = useState("");
  const setAuth = useStore((s) => s.setAuth);
  const router = useRouter();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const r = await fetch("/api/auth/login", {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ email, password: pw, totp: totp || undefined }),
    });
    if (!r.ok) { setErr("Geçersiz giriş"); return; }
    const d = await r.json();
    setAuth(d.token, d.role);
    router.replace("/");
  };

  return (
    <div className="min-h-dvh grid place-items-center px-4">
      <form onSubmit={submit} className="w-full max-w-sm bg-bg-elev border border-line rounded-2xl p-6 space-y-3">
        <h1 className="text-xl font-semibold">Nexus girişi</h1>
        <input value={email} onChange={(e) => setEmail(e.target.value)}
               className="w-full bg-bg-soft px-3 py-2 rounded outline-none" placeholder="e-posta"/>
        <input type="password" value={pw} onChange={(e) => setPw(e.target.value)}
               className="w-full bg-bg-soft px-3 py-2 rounded outline-none" placeholder="parola"/>
        <input value={totp} onChange={(e) => setTotp(e.target.value)}
               className="w-full bg-bg-soft px-3 py-2 rounded outline-none" placeholder="TOTP (opsiyonel)"/>
        {err && <div className="text-down text-sm">{err}</div>}
        <button className="w-full py-2 rounded bg-accent text-bg font-medium">Giriş</button>
      </form>
    </div>
  );
}
