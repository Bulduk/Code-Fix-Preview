"use client";
import { useStore } from "@/lib/store";

export default function Home() {
  const { pnl, signals, ticks } = useStore();
  return (
    <div className="space-y-4">
      <section className="grid grid-cols-3 gap-3">
        <Card title="Equity" value={pnl?.equity ?? 0}/>
        <Card title="Realized" value={pnl?.realized ?? 0}/>
        <Card title="Unrealized" value={pnl?.unrealized ?? 0}/>
      </section>

      <section className="bg-bg-elev border border-line rounded-xl p-3">
        <div className="text-text-dim text-xs mb-2">Canlı sinyaller</div>
        <ul className="divide-y divide-line max-h-[40vh] overflow-auto">
          {signals.slice(0, 50).map((s) => (
            <li key={s.id} className="py-2 flex items-center justify-between text-sm">
              <span><b>{s.strategy}</b> · {s.ex}:{s.sym}</span>
              <span className={s.side === "buy" ? "text-up" : "text-down"}>
                {s.side.toUpperCase()} {(s.strength * 100).toFixed(0)}%
              </span>
            </li>
          ))}
          {signals.length === 0 && <li className="py-6 text-text-dim text-sm text-center">Henüz sinyal yok</li>}
        </ul>
      </section>

      <section className="bg-bg-elev border border-line rounded-xl p-3">
        <div className="text-text-dim text-xs mb-2">Tick akışı</div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-sm">
          {Object.entries(ticks).slice(0, 12).map(([k, v]) => (
            <div key={k} className="bg-bg-soft rounded px-2 py-1.5 flex justify-between">
              <span className="truncate">{k}</span>
              <span className="font-mono">{v.px.toFixed(2)}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function Card({ title, value }: { title: string; value: number }) {
  return (
    <div className="bg-bg-elev border border-line rounded-xl p-3">
      <div className="text-text-dim text-xs">{title}</div>
      <div className={`text-lg font-mono ${value >= 0 ? "text-up" : "text-down"}`}>
        {value.toFixed(2)}
      </div>
    </div>
  );
}
