"use client";
import { useEffect, useState } from "react";
import { useStore } from "@/lib/store";

const KINDS = ["scalping","meanreversion","momentum","breakout","grid",
               "marketmaking","dca","trendfollowing","arbitrage"];

export default function Strategies() {
  const token = useStore((s) => s.token);
  const [list, setList] = useState<any[]>([]);

  const load = () => fetch("/api/strategies", { headers: { authorization: `Bearer ${token}` } })
    .then((r) => r.json()).then(setList);
  useEffect(() => { if (token) load(); }, [token]);

  const toggle = async (s: any) => {
    await fetch(`/api/strategies/${s.id}`, {
      method: "PUT",
      headers: { "content-type": "application/json", authorization: `Bearer ${token}` },
      body: JSON.stringify({ ...s, enabled: !s.enabled }),
    });
    load();
  };

  const create = async () => {
    const name = prompt("Strateji adı?"); if (!name) return;
    const kind = prompt(`Tip? (${KINDS.join(", ")})`, "scalping"); if (!kind) return;
    await fetch("/api/strategies", {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${token}` },
      body: JSON.stringify({ name, kind, enabled: false, params: {}, allocation: 0 }),
    });
    load();
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-semibold">Stratejiler</h1>
        <button onClick={create} className="px-3 py-1.5 rounded bg-accent text-bg text-sm">Yeni</button>
      </div>
      <div className="bg-bg-elev border border-line rounded-xl divide-y divide-line">
        {list.map((s) => (
          <div key={s.id} className="px-3 py-2 flex items-center justify-between">
            <div>
              <div className="text-sm font-medium">{s.name}</div>
              <div className="text-xs text-text-dim">{s.kind}</div>
            </div>
            <button onClick={() => toggle(s)}
                    className={`px-3 py-1 rounded text-xs ${s.enabled ? "bg-up text-bg" : "bg-bg-soft text-text-dim"}`}>
              {s.enabled ? "ON" : "OFF"}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
