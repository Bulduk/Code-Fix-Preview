"use client";
import { useEffect, useState } from "react";
import { useStore } from "@/lib/store";

export default function Audit() {
  const token = useStore((s) => s.token);
  const [list, setList] = useState<any[]>([]);
  useEffect(() => {
    if (!token) return;
    fetch("/api/audit?limit=200", { headers: { authorization: `Bearer ${token}` } })
      .then((r) => r.ok ? r.json() : []).then(setList).catch(() => {});
  }, [token]);
  return (
    <div className="bg-bg-elev border border-line rounded-xl divide-y divide-line">
      {list.map((a: any) => (
        <div key={a.id} className="px-3 py-2 text-sm">
          <div className="flex justify-between">
            <span className="font-medium">{a.action}</span>
            <span className="text-xs text-text-dim font-mono">{new Date(a.ts).toLocaleString()}</span>
          </div>
          <div className="text-xs text-text-dim">{a.target}</div>
        </div>
      ))}
      {list.length === 0 && <div className="px-3 py-6 text-text-dim text-sm text-center">Kayıt yok</div>}
    </div>
  );
}
