"use client";
import { useEffect, useState } from "react";
import { useStore } from "@/lib/store";

const EXCHANGES = ["binance","bybit","okx","coinbase","kraken","bitmex","dydx","hyperliquid","ibkr","polymarket"];
const MODES = ["paper", "testnet", "live"];

export default function Exchanges() {
  const token = useStore((s) => s.token);
  const [list, setList] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ exchange: "binance", label: "", mode: "testnet",
                                      api_key: "", api_secret: "", passphrase: "" });

  const load = () => fetch("/api/exchanges", { headers: { authorization: `Bearer ${token}` } })
    .then((r) => r.json()).then(setList);
  useEffect(() => { if (token) load(); }, [token]);

  const create = async () => {
    await fetch("/api/exchanges", {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${token}` },
      body: JSON.stringify(form),
    });
    setOpen(false); setForm({ ...form, api_key: "", api_secret: "", passphrase: "" }); load();
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-semibold">Borsa hesapları</h1>
        <button onClick={() => setOpen(true)} className="px-3 py-1.5 rounded bg-accent text-bg text-sm">Yeni</button>
      </div>

      <div className="bg-bg-elev border border-line rounded-xl divide-y divide-line">
        {list.map((a) => (
          <div key={a.id} className="px-3 py-2 flex items-center justify-between text-sm">
            <div>
              <div className="font-medium">{a.exchange} · {a.label}</div>
              <div className="text-xs text-text-dim">mod: {a.mode}</div>
            </div>
            <span className={`text-xs px-2 py-0.5 rounded ${a.is_active ? "bg-up/20 text-up" : "bg-bg-soft"}`}>
              {a.is_active ? "active" : "off"}
            </span>
          </div>
        ))}
        {list.length === 0 && <div className="px-3 py-6 text-text-dim text-sm text-center">Hesap yok</div>}
      </div>

      {open && (
        <div className="fixed inset-0 z-40 bg-black/60 grid place-items-center px-4" onClick={() => setOpen(false)}>
          <div className="bg-bg-elev border border-line rounded-xl p-4 w-full max-w-md space-y-2"
               onClick={(e) => e.stopPropagation()}>
            <h2 className="font-medium">Yeni borsa hesabı</h2>
            <select value={form.exchange} onChange={(e) => setForm({ ...form, exchange: e.target.value })}
                    className="w-full bg-bg-soft px-3 py-2 rounded">
              {EXCHANGES.map((x) => <option key={x}>{x}</option>)}
            </select>
            <select value={form.mode} onChange={(e) => setForm({ ...form, mode: e.target.value })}
                    className="w-full bg-bg-soft px-3 py-2 rounded">
              {MODES.map((x) => <option key={x}>{x}</option>)}
            </select>
            <input value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })}
                   placeholder="etiket (örn. main)" className="w-full bg-bg-soft px-3 py-2 rounded"/>
            <input value={form.api_key} onChange={(e) => setForm({ ...form, api_key: e.target.value })}
                   placeholder="API key" className="w-full bg-bg-soft px-3 py-2 rounded font-mono text-xs"/>
            <input value={form.api_secret} onChange={(e) => setForm({ ...form, api_secret: e.target.value })}
                   placeholder="API secret" type="password" className="w-full bg-bg-soft px-3 py-2 rounded font-mono text-xs"/>
            <input value={form.passphrase} onChange={(e) => setForm({ ...form, passphrase: e.target.value })}
                   placeholder="passphrase (OKX/Coinbase)" className="w-full bg-bg-soft px-3 py-2 rounded font-mono text-xs"/>
            <button onClick={create} className="w-full py-2 rounded bg-accent text-bg font-medium">Kaydet</button>
          </div>
        </div>
      )}
    </div>
  );
}
