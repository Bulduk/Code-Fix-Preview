import Link from "next/link";

export default function Admin() {
  const cards = [
    { href: "/admin/exchanges", title: "Borsalar", desc: "Hesap ekle, paper/testnet/live" },
    { href: "/admin/strategies", title: "Stratejiler", desc: "Aç/kapat, parametre" },
    { href: "/admin/users", title: "Kullanıcılar", desc: "RBAC, 2FA" },
    { href: "/admin/audit", title: "Audit Log", desc: "Sistem aksiyonları" },
  ];
  return (
    <div className="grid grid-cols-2 gap-3">
      {cards.map((c) => (
        <Link key={c.href} href={c.href}
              className="bg-bg-elev border border-line rounded-xl p-4 hover:bg-bg-soft transition">
          <div className="font-medium">{c.title}</div>
          <div className="text-text-dim text-xs">{c.desc}</div>
        </Link>
      ))}
    </div>
  );
}
