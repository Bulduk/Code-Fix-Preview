"use client";
import { useEffect, useState } from "react";
import { useStore } from "@/lib/store";

export default function Users() {
  const token = useStore((s) => s.token);
  const [list, setList] = useState<any[]>([]);
  useEffect(() => {
    if (!token) return;
    fetch("/api/users", { headers: { authorization: `Bearer ${token}` } })
      .then((r) => r.ok ? r.json() : []).then(setList).catch(() => {});
  }, [token]);
  return (
    <div className="bg-bg-elev border border-line rounded-xl divide-y divide-line">
      {list.map((u: any) => (
        <div key={u.id} className="px-3 py-2 flex justify-between text-sm">
          <span>{u.email}</span>
          <span className="text-xs text-text-dim">{u.role}</span>
        </div>
      ))}
      {list.length === 0 && <div className="px-3 py-6 text-text-dim text-sm text-center">Kullanıcı yok</div>}
    </div>
  );
}
