import "./globals.css";
import Shell from "@/components/Shell";

export const metadata = { title: "Nexus Trade OS", description: "Trading OS" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="tr">
      <body className="font-sans">
        <Shell>{children}</Shell>
      </body>
    </html>
  );
}
