"use client";
import { useMemo } from "react";
import Link from "next/link";
import { useStore } from "@/lib/store";

export default function Markets() {
  const { ticks } = useStore();
  const rows = useMemo(
    () => Object.entries(ticks).map(([k, v]) => ({ key: k, ...v })).sort((a, b) => a.key.localeCompare(b.key)),
    [ticks],
  );
  return (
    <div className="bg-bg-elev border border-line rounded-xl">
      <div className="px-3 py-2 text-xs text-text-dim grid grid-cols-3">
        <span>Sembol</span><span className="text-right">Fiyat</span><span className="text-right">Aksiyon</span>
      </div>
      <ul className="divide-y divide-line">
        {rows.map((r) => (
          <li key={r.key} className="grid grid-cols-3 px-3 py-2 text-sm items-center">
            <span>{r.key}</span>
            <span className="text-right font-mono">{r.px.toFixed(2)}</span>
            <span className="text-right">
              <Link href={`/trade?sym=${r.key}`} className="text-accent">Trade</Link>
            </span>
          </li>
        ))}
        {rows.length === 0 && <li className="px-3 py-6 text-text-dim text-sm text-center">Veri yok</li>}
      </ul>
    </div>
  );
}
