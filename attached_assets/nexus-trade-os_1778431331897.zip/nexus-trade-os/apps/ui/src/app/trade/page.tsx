"use client";
import { useState } from "react";
import { useSearchParams } from "next/navigation";
import { useStore } from "@/lib/store";

export default function Trade() {
  const sp = useSearchParams();
  const initial = sp.get("sym") || "binance:BTCUSDT";
  const [ex, sym] = initial.split(":");
  const [side, setSide] = useState<"buy" | "sell">("buy");
  const [type, setType] = useState<"market" | "limit">("limit");
  const [qty, setQty] = useState("0.001");
  const [px, setPx] = useState("");
  const token = useStore((s) => s.token);

  const submit = async () => {
    const cmd: any = { c: "place_order", ex, sym, side, type, qty: Number(qty), tif: "gtc" };
    if (type === "limit") cmd.px = Number(px);
    await fetch("/api/orders", {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${token}` },
      body: JSON.stringify(cmd),
    }).catch(() => {});
  };

  return (
    <div className="space-y-3">
      <div className="bg-bg-elev border border-line rounded-xl p-3">
        <div className="text-text-dim text-xs">Sembol</div>
        <div className="text-lg">{ex} : {sym}</div>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <button onClick={() => setSide("buy")}
                className={`py-2 rounded ${side === "buy" ? "bg-up text-bg" : "bg-bg-elev"}`}>BUY</button>
        <button onClick={() => setSide("sell")}
                className={`py-2 rounded ${side === "sell" ? "bg-down text-bg" : "bg-bg-elev"}`}>SELL</button>
      </div>
      <div className="bg-bg-elev border border-line rounded-xl p-3 space-y-2">
        <select value={type} onChange={(e) => setType(e.target.value as any)}
                className="w-full bg-bg-soft px-3 py-2 rounded">
          <option value="limit">Limit</option><option value="market">Market</option>
        </select>
        {type === "limit" && (
          <input value={px} onChange={(e) => setPx(e.target.value)} placeholder="Fiyat"
                 className="w-full bg-bg-soft px-3 py-2 rounded font-mono"/>
        )}
        <input value={qty} onChange={(e) => setQty(e.target.value)} placeholder="Miktar"
               className="w-full bg-bg-soft px-3 py-2 rounded font-mono"/>
        <button onClick={submit}
                className={`w-full py-2.5 rounded font-medium ${side === "buy" ? "bg-up" : "bg-down"} text-bg`}>
          {side === "buy" ? "AL" : "SAT"}
        </button>
      </div>
    </div>
  );
}
