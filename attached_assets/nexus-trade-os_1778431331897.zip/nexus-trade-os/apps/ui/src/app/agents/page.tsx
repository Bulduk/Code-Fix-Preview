"use client";
import { useEffect, useState } from "react";
import { useStore } from "@/lib/store";

export default function Agents() {
  const token = useStore((s) => s.token);
  const [list, setList] = useState<any[]>([]);
  const [sel, setSel] = useState<any | null>(null);
  const [msg, setMsg] = useState("");

  const load = () => fetch("/api/agents", { headers: { authorization: `Bearer ${token}` } })
    .then((r) => r.json()).then(setList);
  useEffect(() => { if (token) load(); }, [token]);

  const invoke = async () => {
    if (!sel) return;
    await fetch(`/api/agents/${sel.id}/invoke`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${token}` },
      body: JSON.stringify({ message: msg }),
    });
    setMsg("");
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
      <ul className="bg-bg-elev border border-line rounded-xl divide-y divide-line">
        {list.map((a) => (
          <li key={a.id} onClick={() => setSel(a)}
              className={`px-3 py-2 cursor-pointer ${sel?.id === a.id ? "bg-bg-soft" : ""}`}>
            <div className="text-sm">{a.name}</div>
            <div className="text-xs text-text-dim">{a.provider} · {a.model}</div>
          </li>
        ))}
        {list.length === 0 && <li className="px-3 py-6 text-text-dim text-sm text-center">Ajan yok</li>}
      </ul>
      <div className="md:col-span-2 bg-bg-elev border border-line rounded-xl p-3">
        {sel ? (
          <>
            <div className="font-medium mb-2">{sel.name}</div>
            <textarea value={msg} onChange={(e) => setMsg(e.target.value)} rows={5}
                      placeholder="Ajana komut/sorgu yaz..."
                      className="w-full bg-bg-soft px-3 py-2 rounded outline-none"/>
            <button onClick={invoke} className="mt-2 px-4 py-2 rounded bg-accent text-bg">Çağır</button>
          </>
        ) : <div className="text-text-dim text-sm">Soldan bir ajan seç</div>}
      </div>
    </div>
  );
}
