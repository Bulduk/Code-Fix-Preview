"use client";
import { useEffect, useState } from "react";
import { useStore } from "@/lib/store";

export default function PnL() {
  const token = useStore((s) => s.token);
  const [rows, setRows] = useState<any[]>([]);
  const [retentionDays, setRetentionDays] = useState(90);

  useEffect(() => {
    if (!token) return;
    fetch("/api/pnl/snapshots?account=default&limit=500", { headers: { authorization: `Bearer ${token}` } })
      .then((r) => r.json()).then(setRows).catch(() => {});
  }, [token]);

  const exportFile = (fmt: "csv" | "json") => {
    window.open(`${process.env.NEXT_PUBLIC_API_URL}/api/pnl/export?fmt=${fmt}&account=default`, "_blank");
  };

  const purge = async () => {
    if (!confirm(`${retentionDays} günden eski PnL kayıtları silinecek. Onayla?`)) return;
    const before = new Date(Date.now() - retentionDays * 86400000).toISOString();
    await fetch(`/api/pnl/purge?account=default&before=${encodeURIComponent(before)}`, {
      method: "DELETE", headers: { authorization: `Bearer ${token}` },
    });
    alert("Temizlendi.");
  };

  return (
    <div className="space-y-3">
      <div className="bg-bg-elev border border-line rounded-xl p-3 flex flex-wrap gap-2 items-center">
        <button onClick={() => exportFile("csv")} className="px-3 py-1.5 rounded bg-bg-soft text-sm">CSV indir</button>
        <button onClick={() => exportFile("json")} className="px-3 py-1.5 rounded bg-bg-soft text-sm">JSON indir</button>
        <div className="flex items-center gap-2 ml-auto">
          <span className="text-text-dim text-xs">Sakla (gün)</span>
          <input type="number" min={1} value={retentionDays}
                 onChange={(e) => setRetentionDays(Number(e.target.value))}
                 className="w-20 bg-bg-soft px-2 py-1 rounded text-sm"/>
          <button onClick={purge} className="px-3 py-1.5 rounded bg-down text-bg text-sm">Eski kayıtları temizle</button>
        </div>
      </div>

      <div className="bg-bg-elev border border-line rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-bg-soft text-text-dim">
            <tr>
              <th className="text-left px-3 py-2">Zaman</th>
              <th className="text-right px-3 py-2">Equity</th>
              <th className="text-right px-3 py-2">Realized</th>
              <th className="text-right px-3 py-2">Unrealized</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={i} className="border-t border-line">
                <td className="px-3 py-1.5 font-mono text-xs">{new Date(r.ts).toLocaleString()}</td>
                <td className="px-3 py-1.5 text-right font-mono">{(+r.equity).toFixed(2)}</td>
                <td className="px-3 py-1.5 text-right font-mono">{(+r.realized).toFixed(2)}</td>
                <td className="px-3 py-1.5 text-right font-mono">{(+r.unrealized).toFixed(2)}</td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={4} className="text-center py-6 text-text-dim">Kayıt yok</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
