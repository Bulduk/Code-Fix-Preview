/** @type {import('next').NextConfig} */
export default {
  output: "standalone",
  reactStrictMode: true,
  experimental: { typedRoutes: true },
  async rewrites() {
    return [
      { source: "/api/:path*", destination: `${process.env.NEXT_PUBLIC_API_URL}/api/:path*` },
    ];
  },
};
