import type { Config } from "tailwindcss";
export default {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg:    { DEFAULT: "#0b0e11", elev: "#161a1e", soft: "#1e2329" },
        line:  "#2b3139",
        text:  { DEFAULT: "#eaecef", dim: "#848e9c" },
        up:    "#0ecb81",
        down:  "#f6465d",
        accent: "#fcd535",
      },
      fontFamily: { sans: ["Inter","system-ui","sans-serif"] },
      boxShadow: { fab: "0 8px 24px rgba(0,0,0,.4)" },
    },
  },
  plugins: [],
} satisfies Config;
