"""Agent runtime — komut akışından 'agent.invoke' çekip ajanı çalıştırır.

Özellikler:
  - Çoklu LLM sağlayıcı (Anthropic, OpenAI, Ollama)
  - Sistem talimatı + prompt versiyonlama
  - Tool çağrıları (maksimum 6 round)
  - Bütçe takibi
  - Event stream'e geri yazma
"""
import asyncio, json, msgpack, signal as sig, time
import asyncpg, redis.asyncio as redis
from pydantic_settings import BaseSettings, SettingsConfigDict
import structlog

from .providers import make
from .tools import ToolRegistry

log = structlog.get_logger()

class S(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    database_url: str
    redis_url: str
s = S()  # type: ignore[call-arg]

class AgentRuntime:
    def __init__(self) -> None:
        self.rd: redis.Redis | None = None
        self.pg: asyncpg.Pool | None = None
        self.tools: ToolRegistry | None = None
        self.stop = asyncio.Event()

    async def start(self) -> None:
        self.rd = redis.from_url(s.redis_url, decode_responses=False)
        self.pg = await asyncpg.create_pool(s.database_url, min_size=1, max_size=2)
        self.tools = ToolRegistry(self.rd)
        await self.loop()

    async def stop(self) -> None:
        self.stop.set()
        if self.rd: await self.rd.aclose()
        if self.pg: await self.pg.close()

    async def loop(self) -> None:
        last = "$"
        while not self.stop.is_set():
            res = await self.rd.xread({"nexus:commands": last}, block=1000, count=50)
            if not res: continue
            for _, entries in res:
                for eid, fields in entries:
                    last = eid
                    try:
                        cmd = msgpack.unpackb(fields[b"d"], raw=False)
                        if cmd.get("c") == "agent.invoke":
                            asyncio.create_task(self.run_agent(cmd))
                    except Exception as e:
                        log.error("cmd.fail", err=str(e))

    async def run_agent(self, cmd: dict) -> None:
        agent_id = cmd["agent_id"]; user_msg = cmd.get("message", "")
        async with self.pg.acquire() as c:
            row = await c.fetchrow(
                "SELECT name, provider, model, system_instruction, prompt, tools "
                "FROM agents WHERE id=$1 AND enabled=true", agent_id)
        if not row:
            await self.emit_agent_msg(agent_id, "error", "agent not found or disabled")
            return

        import os
        key_env = {"anthropic":"ANTHROPIC_API_KEY","openai":"OPENAI_API_KEY"}.get(row["provider"])
        api_key = os.getenv(key_env, "") if key_env else ""
        provider = make(row["provider"], api_key=api_key)

        system = row["system_instruction"]
        if row["prompt"]:
            system = system + "\n\n" + row["prompt"]

        ext_tools = json.loads(row["tools"]) if isinstance(row["tools"], str) else row["tools"]
        tool_specs = self.tool_specs(ext_tools)

        messages = [{"role": "user", "content": user_msg}]
        for _ in range(6):  # max 6 tool rounds
            r = await provider.chat(system, messages, tool_specs, row["model"])
            await self.emit_agent_msg(agent_id, "step", r)
            tool_calls = self.extract_tool_calls(row["provider"], r)
            if not tool_calls: break
            for tc in tool_calls:
                result = await self.tools.call(tc["name"], tc["args"], ext_tools)
                messages.append({"role":"assistant", "content": json.dumps(r["content"])[:4000]})
                messages.append({"role":"user",
                                 "content": f"[tool:{tc['name']}] {json.dumps(result)[:4000]}"})
        await self.emit_agent_msg(agent_id, "done", {})

    def tool_specs(self, external: list[dict]) -> list[dict]:
        builtin = [
            {"name":"place_order","description":"Place an order","input_schema":{
              "type":"object","properties":{
                "ex":{"type":"string"},"sym":{"type":"string"},
                "side":{"type":"string","enum":["buy","sell"]},
                "type":{"type":"string","enum":["market","limit"]},
                "qty":{"type":"number"},"px":{"type":"number"},
                "tif":{"type":"string"}}, "required":["ex","sym","side","type","qty"]}},
            {"name":"cancel_order","description":"Cancel order","input_schema":{
              "type":"object","properties":{"ex":{"type":"string"},"order_id":{"type":"string"}},
              "required":["ex","order_id"]}},
            {"name":"kill_switch","description":"Emergency stop","input_schema":{
              "type":"object","properties":{"scope":{"type":"string"},"target":{"type":"string"}}}},
            {"name":"get_signals","description":"Fetch recent signals","input_schema":{
              "type":"object","properties":{"strategy":{"type":"string"},"limit":{"type":"integer"}}}},
        ]
        return builtin + [{"name": t["name"], "description": t.get("description",""),
                           "input_schema": t.get("input_schema", {"type":"object"})}
                          for t in external]

    def extract_tool_calls(self, provider: str, r: dict) -> list[dict]:
        out = []
        if provider == "anthropic":
            for b in r.get("content", []):
                if b.get("type") == "tool_use":
                    out.append({"name": b["name"], "args": b.get("input", {})})
        elif provider == "openai":
            tc = r.get("content", {}).get("tool_calls") or []
            for c in tc:
                fn = c.get("function", {})
                try: args = json.loads(fn.get("arguments","{}"))
                except Exception: args = {}
                out.append({"name": fn.get("name"), "args": args})
        return out

    async def emit_agent_msg(self, agent_id: str, kind: str, payload) -> None:
        await self.rd.xadd("nexus:events", {b"d": msgpack.packb({
            "t":"agent_msg","agent_id":agent_id,"kind":kind,"payload":payload,
            "ts": int(time.time()*1e9)})}, maxlen=50000, approximate=True)

async def amain() -> None:
    rt = AgentRuntime()
    loop = asyncio.get_running_loop()
    for sg in (sig.SIGINT, sig.SIGTERM):
        loop.add_signal_handler(sg, lambda: asyncio.create_task(rt.stop()))
    log.info("agents.start")
    try:
        await rt.start()
    finally:
        await rt.stop()

if __name__ == "__main__":
    asyncio.run(amain())
