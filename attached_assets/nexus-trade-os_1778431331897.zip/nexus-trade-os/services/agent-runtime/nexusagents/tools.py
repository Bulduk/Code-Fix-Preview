"""Tool registry — dahili (place_order, get_pnl) + kullanıcı tarafından
OpenAPI olarak yüklenmiş harici API'ler.

Her ajan admin panelden tool ekleyebilir:
  - OpenAPI/JSON schema yükleme
  - HTTP endpoint çağrısı
  - Sistem komutları (place_order, cancel_order, kill_switch, get_signals)
"""
from __future__ import annotations
from typing import Any, Callable, Awaitable
import httpx, msgpack, redis.asyncio as redis

ToolFn = Callable[[dict], Awaitable[dict]]

class ToolRegistry:
    def __init__(self, rd: redis.Redis):
        self.rd = rd
        self.builtins: dict[str, ToolFn] = {
            "place_order": self.place_order,
            "cancel_order": self.cancel_order,
            "kill_switch": self.kill_switch,
            "get_signals": self.get_signals,
        }

    async def call(self, name: str, args: dict, external: list[dict]) -> dict:
        if name in self.builtins:
            return await self.builtins[name](args)
        spec = next((t for t in external if t["name"] == name), None)
        if not spec: return {"error": f"unknown tool: {name}"}
        return await self.http_tool(spec, args)

    async def publish_cmd(self, c: dict) -> dict:
        await self.rd.xadd("nexus:commands", {b"d": msgpack.packb(c)},
                           maxlen=10000, approximate=True)
        return {"ok": True, "queued": c.get("c")}

    async def place_order(self, a: dict) -> dict:
        return await self.publish_cmd({"c":"place_order", **a})

    async def cancel_order(self, a: dict) -> dict:
        return await self.publish_cmd({"c":"cancel_order", **a})

    async def kill_switch(self, a: dict) -> dict:
        return await self.publish_cmd({"c":"kill_switch", **a})

    async def get_signals(self, a: dict) -> dict:
        res = await self.rd.xrevrange("nexus:events", count=200)
        out = []
        for id, fields in res:
            try:
                ev = msgpack.unpackb(fields[b"d"], raw=False)
                if ev.get("t") == "signal" and (not a.get("strategy") or ev["strategy"] == a["strategy"]):
                    out.append(ev)
                    if len(out) >= a.get("limit", 20): break
            except Exception: continue
        return {"signals": out}

    async def http_tool(self, spec: dict, args: dict) -> dict:
        method = spec.get("method", "POST").upper()
        url = spec["url"]
        headers = spec.get("headers", {})
        async with httpx.AsyncClient(timeout=30) as cx:
            r = await cx.request(method, url, headers=headers,
                                 json=args if method in ("POST","PUT","PATCH") else None,
                                 params=args if method == "GET" else None)
            try: return {"status": r.status_code, "data": r.json()}
            except Exception: return {"status": r.status_code, "text": r.text[:2000]}
