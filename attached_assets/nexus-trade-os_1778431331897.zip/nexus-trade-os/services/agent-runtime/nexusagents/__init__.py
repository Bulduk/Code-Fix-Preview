"""Nexus Agent Runtime — LLM-driven trading agents."""
__version__ = "0.1.0"
