"""Çoklu LLM sağlayıcı — tek arayüz.

Desteklenen:
  - anthropic: Claude (API key)
  - openai: GPT-4o, o1 (API key)
  - ollama: Yerel model (base URL)
"""
from __future__ import annotations
from typing import Any
import httpx
import anthropic, openai

class LLMProvider:
    async def chat(self, system: str, messages: list[dict], tools: list[dict],
                   model: str, max_tokens: int = 1024) -> dict: ...

class AnthropicProvider(LLMProvider):
    def __init__(self, api_key: str): self.c = anthropic.AsyncAnthropic(api_key=api_key)
    async def chat(self, system, messages, tools, model, max_tokens=1024):
        r = await self.c.messages.create(
            model=model, system=system, messages=messages,
            tools=tools or [], max_tokens=max_tokens,
        )
        return {"content": [b.model_dump() for b in r.content],
                "stop_reason": r.stop_reason,
                "usage": {"in": r.usage.input_tokens, "out": r.usage.output_tokens}}

class OpenAIProvider(LLMProvider):
    def __init__(self, api_key: str): self.c = openai.AsyncOpenAI(api_key=api_key)
    async def chat(self, system, messages, tools, model, max_tokens=1024):
        msgs = [{"role": "system", "content": system}, *messages]
        r = await self.c.chat.completions.create(
            model=model, messages=msgs,
            tools=[{"type":"function","function":t} for t in tools] if tools else None,
            max_tokens=max_tokens,
        )
        m = r.choices[0].message
        return {"content": m.model_dump(), "stop_reason": r.choices[0].finish_reason,
                "usage": {"in": r.usage.prompt_tokens, "out": r.usage.completion_tokens}}

class OllamaProvider(LLMProvider):
    def __init__(self, base: str = "http://host.docker.internal:11434"): self.base = base
    async def chat(self, system, messages, tools, model, max_tokens=1024):
        async with httpx.AsyncClient(timeout=120) as cx:
            r = await cx.post(f"{self.base}/api/chat", json={
                "model": model, "stream": False,
                "messages": [{"role":"system","content":system}, *messages],
                "options": {"num_predict": max_tokens},
            })
            r.raise_for_status(); d = r.json()
            return {"content": d.get("message", {}),
                    "stop_reason": d.get("done_reason","stop"),
                    "usage": {"in": d.get("prompt_eval_count",0),
                              "out": d.get("eval_count",0)}}

def make(provider: str, **kw) -> LLMProvider:
    if provider == "anthropic": return AnthropicProvider(kw["api_key"])
    if provider == "openai":    return OpenAIProvider(kw["api_key"])
    if provider == "ollama":    return OllamaProvider(kw.get("base", "http://host.docker.internal:11434"))
    raise ValueError(f"unknown provider: {provider}")
