"""Signal engine — tails ticks/bars, runs enabled strategies, emits signals."""
import asyncio, msgpack, time, json, signal as sig
from collections import defaultdict, deque
import asyncpg, redis.asyncio as redis
from pydantic_settings import BaseSettings, SettingsConfigDict
import structlog

from nexussignal.strategies.base import MarketCtx
from nexussignal.strategies.library import REGISTRY

log = structlog.get_logger()

class S(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    database_url: str
    redis_url: str
s = S()  # type: ignore[call-arg]

S_EVENTS = "nexus:events"

class SignalEngine:
    def __init__(self) -> None:
        self.rd: redis.Redis | None = None
        self.pg: asyncpg.Pool | None = None
        self.active: dict[str, object] = {}     # name -> Strategy instance
        self.bars: dict[tuple[str, str], deque] = defaultdict(lambda: deque(maxlen=300))
        self.book: dict[tuple[str, str], dict] = {}
        self.stop = asyncio.Event()

    async def start(self) -> None:
        self.rd = redis.from_url(s.redis_url, decode_responses=False)
        self.pg = await asyncpg.create_pool(s.database_url, min_size=1, max_size=2)
        await self.reload_strategies()
        await asyncio.gather(self.tail_events(), self.reload_loop())

    async def stop(self) -> None:
        self.stop.set()
        if self.rd: await self.rd.aclose()
        if self.pg: await self.pg.close()

    async def reload_strategies(self) -> None:
        """Load enabled strategies from DB."""
        assert self.pg
        async with self.pg.acquire() as c:
            rows = await c.fetch(
                "SELECT name, kind, enabled, params FROM strategies WHERE enabled = true")
        new = {}
        for r in rows:
            cls = REGISTRY.get(r["kind"])
            if cls:
                params = json.loads(r["params"]) if isinstance(r["params"], str) else r["params"]
                new[r["name"]] = cls(params)
        self.active = new
        log.info("strategies.reloaded", n=len(new), names=list(new))

    async def reload_loop(self) -> None:
        while not self.stop.is_set():
            await asyncio.sleep(15)
            try:
                await self.reload_strategies()
            except Exception as e:
                log.error("reload.fail", err=str(e))

    async def publish(self, ev: dict) -> None:
        assert self.rd
        await self.rd.xadd(S_EVENTS, {b"d": msgpack.packb(ev)},
                           maxlen=50000, approximate=True)

    async def tail_events(self) -> None:
        assert self.rd
        last = "$"
        while not self.stop.is_set():
            res = await self.rd.xread({S_EVENTS: last}, block=1000, count=200)
            if not res: continue
            for _, entries in res:
                for eid, fields in entries:
                    last = eid
                    try:
                        ev = msgpack.unpackb(fields[b"d"], raw=False)
                        await self.on_event(ev)
                    except Exception as e:
                        log.error("ev.fail", err=str(e))

    async def on_event(self, ev: dict) -> None:
        t = ev.get("t")
        if t == "bar":
            key = (ev["ex"], ev["sym"])
            self.bars[key].append(ev)
        elif t == "tick":
            key = (ev["ex"], ev["sym"])
            self.book[key] = {"last": ev["px"], "ts": ev["ts"]}
            await self.run_all(ev["ex"], ev["sym"])
        elif t == "book":
            key = (ev["ex"], ev["sym"])
            self.book[key] = {**self.book.get(key, {}),
                              "bid": ev.get("bid"), "ask": ev.get("ask"),
                              "bid_qty": ev.get("bid_qty"), "ask_qty": ev.get("ask_qty")}

    async def run_all(self, ex: str, sym: str) -> None:
        b = self.book.get((ex, sym), {})
        if "last" not in b: return
        bars = list(self.bars.get((ex, sym), []))
        ctx = MarketCtx(
            ex=ex, sym=sym, last=b["last"],
            bid=b.get("bid", b["last"]), ask=b.get("ask", b["last"]),
            bid_qty=b.get("bid_qty", 0), ask_qty=b.get("ask_qty", 0),
            closes=[bb["c"] for bb in bars], highs=[bb["h"] for bb in bars],
            lows=[bb["l"] for bb in bars], volumes=[bb["v"] for bb in bars],
        )
        for strat in self.active.values():
            try:
                sig = strat.on_market(ctx)
                if sig: await self.publish(sig.to_event())
            except Exception as e:
                log.error("strat.fail", strat=strat.name, err=str(e))

async def amain() -> None:
    eng = SignalEngine()
    loop = asyncio.get_running_loop()
    for sg in (sig.SIGINT, sig.SIGTERM):
        loop.add_signal_handler(sg, lambda: asyncio.create_task(eng.stop()))
    log.info("signal.start")
    try:
        await eng.start()
    finally:
        await eng.stop()

if __name__ == "__main__":
    asyncio.run(amain())
