"""Strategy library — UI'dan açılır/kapanır, parametre hot-reload.

Strategies:
  - Scalping: orderbook imbalance + microprice
  - MeanReversion: Bollinger + z-score
  - Momentum: EMA cross
  - Breakout: Donchian channel
  - Grid: geometric/arithmetic grid
  - MarketMaking: Avellaneda-Stoikov simplified
  - DCA: periodic dollar-cost averaging
  - TrendFollowing: Donchian + ATR trail
  - Arbitrage: cross-exchange edge (placeholder)
"""
from __future__ import annotations
import numpy as np
from .base import Strategy, MarketCtx, Signal

# Rust hot-path; eğer modül kurulmadıysa numpy fallback.
try:
    from nexushotindicators import ema, rsi, microprice  # type: ignore
except Exception:  # pragma: no cover
    def ema(v, p):
        a = np.array(v); k = 2/(p+1)
        o = np.empty_like(a); o[0] = a[0]
        for i in range(1, len(a)): o[i] = a[i] * k + o[i-1] * (1-k)
        return o.tolist()
    def rsi(v, p): return list(np.full(len(v), 50.0))
    def microprice(b, a, bq, aq):
        s = bq + aq
        return (b + a) / 2 if s <= 0 else (b * aq + a * bq) / s

class Scalping(Strategy):
    name = "scalping"
    params = {"min_imbalance": 0.65, "min_strength": 0.55}

    def on_market(self, ctx: MarketCtx) -> Signal | None:
        s = ctx.bid_qty + ctx.ask_qty
        if s <= 0: return None
        imb = ctx.bid_qty / s
        mp = microprice(ctx.bid, ctx.ask, ctx.bid_qty, ctx.ask_qty)
        if imb >= self.params["min_imbalance"] and mp > ctx.last:
            return self.emit(ctx, "buy", float(imb), "ob_imbalance_long", mp=mp)
        if (1 - imb) >= self.params["min_imbalance"] and mp < ctx.last:
            return self.emit(ctx, "sell", float(1 - imb), "ob_imbalance_short", mp=mp)
        return None

class MeanReversion(Strategy):
    name = "meanreversion"
    params = {"period": 20, "z": 2.0}

    def on_market(self, ctx: MarketCtx) -> Signal | None:
        p = self.params["period"]
        if len(ctx.closes) < p: return None
        a = np.array(ctx.closes[-p:])
        mu, sd = a.mean(), a.std()
        if sd == 0: return None
        z = (ctx.last - mu) / sd
        if z <= -self.params["z"]:
            return self.emit(ctx, "buy", min(1.0, abs(z)/4), "z_low", z=float(z))
        if z >= self.params["z"]:
            return self.emit(ctx, "sell", min(1.0, abs(z)/4), "z_high", z=float(z))
        return None

class Momentum(Strategy):
    name = "momentum"
    params = {"fast": 12, "slow": 26}

    def on_market(self, ctx: MarketCtx) -> Signal | None:
        if len(ctx.closes) < self.params["slow"] + 2: return None
        f = ema(ctx.closes, self.params["fast"])[-1]
        s = ema(ctx.closes, self.params["slow"])[-1]
        prev_f = ema(ctx.closes[:-1], self.params["fast"])[-1]
        prev_s = ema(ctx.closes[:-1], self.params["slow"])[-1]
        if prev_f <= prev_s and f > s:
            return self.emit(ctx, "buy", 0.7, "ema_cross_up", fast=f, slow=s)
        if prev_f >= prev_s and f < s:
            return self.emit(ctx, "sell", 0.7, "ema_cross_down", fast=f, slow=s)
        return None

class Breakout(Strategy):
    name = "breakout"
    params = {"period": 20}

    def on_market(self, ctx: MarketCtx) -> Signal | None:
        p = self.params["period"]
        if len(ctx.highs) < p: return None
        hi = max(ctx.highs[-p:]); lo = min(ctx.lows[-p:])
        if ctx.last > hi: return self.emit(ctx, "buy", 0.8, "donchian_break_up", hi=hi)
        if ctx.last < lo: return self.emit(ctx, "sell", 0.8, "donchian_break_dn", lo=lo)
        return None

class Grid(Strategy):
    name = "grid"
    params = {"levels": 10, "spacing_pct": 0.5, "anchor": None}

    def on_market(self, ctx: MarketCtx) -> Signal | None:
        anchor = self.params.get("anchor") or ctx.last
        step = anchor * self.params["spacing_pct"] / 100
        diff = (ctx.last - anchor) / step
        lvl = round(diff)
        if abs(lvl) > self.params["levels"]: return None
        if lvl < 0: return self.emit(ctx, "buy", 0.4, "grid_buy", level=lvl)
        if lvl > 0: return self.emit(ctx, "sell", 0.4, "grid_sell", level=lvl)
        return None

class MarketMaking(Strategy):
    name = "marketmaking"
    params = {"spread_bps": 10, "size": 0.001}

    def on_market(self, ctx: MarketCtx) -> Signal | None:
        spr = ctx.last * self.params["spread_bps"] / 10000
        return self.emit(ctx, "buy", 0.5, "mm_quote",
                         bid=ctx.last - spr, ask=ctx.last + spr,
                         size=self.params["size"], paired=True)

class DCA(Strategy):
    name = "dca"
    params = {"interval_sec": 3600, "size": 0.001}
    last_ts = 0

    def on_market(self, ctx: MarketCtx) -> Signal | None:
        import time as t
        now = int(t.time())
        if now - self.last_ts < self.params["interval_sec"]: return None
        self.last_ts = now
        return self.emit(ctx, "buy", 0.3, "dca_tick", size=self.params["size"])

class TrendFollowing(Strategy):
    name = "trendfollowing"
    params = {"period": 20, "atr_mult": 2.0}

    def on_market(self, ctx: MarketCtx) -> Signal | None:
        p = self.params["period"]
        if len(ctx.closes) < p + 1: return None
        hi = max(ctx.highs[-p:]); lo = min(ctx.lows[-p:])
        rng = np.array([h-l for h, l in zip(ctx.highs[-p:], ctx.lows[-p:])])
        atr = float(rng.mean())
        if ctx.last > hi - atr * 0.1:
            return self.emit(ctx, "buy", 0.7, "donchian_trend_up",
                             stop=ctx.last - atr * self.params["atr_mult"])
        if ctx.last < lo + atr * 0.1:
            return self.emit(ctx, "sell", 0.7, "donchian_trend_dn",
                             stop=ctx.last + atr * self.params["atr_mult"])
        return None

class Arbitrage(Strategy):
    """Cross-exchange arb — needs price feed from multiple ex; simplified here."""
    name = "arbitrage"
    params = {"min_edge_bps": 5}

    def on_market(self, ctx: MarketCtx) -> Signal | None:
        edge = getattr(ctx, "meta_edge_bps", 0.0)
        if edge >= self.params["min_edge_bps"]:
            return self.emit(ctx, "buy", min(1.0, edge/50), "arb_edge", edge_bps=edge)
        return None

REGISTRY: dict[str, type[Strategy]] = {
    s.name: s for s in [Scalping, MeanReversion, Momentum, Breakout, Grid,
                        MarketMaking, DCA, TrendFollowing, Arbitrage]
}
