"""Strategy library — 9 trading strategies."""
from .library import REGISTRY
__all__ = ["REGISTRY"]
