"""Strategy base class for signal generation."""
from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any
import uuid, time

@dataclass
class Signal:
    id: str
    strategy: str
    ex: str
    sym: str
    side: str          # buy | sell
    strength: float    # 0..1
    reason: str
    meta: dict[str, Any] = field(default_factory=dict)
    ts: int = 0

    def to_event(self) -> dict:
        return {"t": "signal", **self.__dict__}

@dataclass
class MarketCtx:
    ex: str
    sym: str
    last: float
    bid: float
    ask: float
    bid_qty: float
    ask_qty: float
    closes: list[float]            # latest N closes
    highs: list[float]
    lows: list[float]
    volumes: list[float]

class Strategy(ABC):
    name: str = "base"
    enabled: bool = False
    params: dict[str, Any] = {}

    def __init__(self, params: dict[str, Any] | None = None) -> None:
        self.params = {**self.__class__.params, **(params or {})}

    @abstractmethod
    def on_market(self, ctx: MarketCtx) -> Signal | None: ...

    def emit(self, ctx: MarketCtx, side: str, strength: float, reason: str,
             **meta: Any) -> Signal:
        return Signal(
            id=uuid.uuid4().hex, strategy=self.name, ex=ctx.ex,
            sym=ctx.sym, side=side, strength=strength, reason=reason,
            meta=meta, ts=int(time.time() * 1e9)
        )
