"""Nexus Signal Engine — multi-strategy signal generator."""
__version__ = "0.1.0"
