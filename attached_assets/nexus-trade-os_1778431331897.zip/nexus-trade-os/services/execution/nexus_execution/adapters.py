"""Exchange adapter factory — maps (exchange, mode) → Nautilus client config.

Supported: binance, bybit, okx, coinbase, kraken, bitmex, dydx, hyperliquid,
ibkr, polymarket. Each mode (paper/testnet/live) uses Nautilus' built-in
config or routes to SimulatedExchange for paper mode.

Binance modes:
  - paper: SimulatedExchange with real market data
  - testnet: BinanceEnvironment.TESTNET (legacy testnet)
  - live: BinanceEnvironment.LIVE (production)
  - demo: BinanceEnvironment.DEMO (simulated funds, production infra)

NautilusTrader Binance config per official docs:
  https://nautilustrader.io/docs/nightly/integrations/binance/
"""
from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class AdapterSpec:
    exchange: str
    mode: str
    data_client: dict[str, Any]
    exec_client: dict[str, Any]

# Per-exchange mode config
# Keys come from vault (decrypted) at runtime
BASE = {
    "binance": {
        "paper":    {"simulated": True},
        "testnet":  {"environment": "TESTNET"},
        "demo":     {"environment": "DEMO"},
        "live":     {"environment": "LIVE"},
    },
    "bybit": {
        "paper":    {"simulated": True},
        "testnet":  {"testnet": True},
        "live":     {"testnet": False},
    },
    "okx": {
        "paper":    {"simulated": True},
        "testnet":  {"is_demo": True},
        "live":     {"is_demo": False},
    },
    "coinbase": {
        "paper":    {"simulated": True},
        "testnet":  {"sandbox": True},
        "live":     {"sandbox": False},
    },
    "bitmex": {
        "paper":    {"simulated": True},
        "testnet":  {"testnet": True},
        "live":     {"testnet": False},
    },
    "dydx":        {"paper": {"simulated": True}, "testnet": {"testnet": True}, "live": {"testnet": False}},
    "hyperliquid": {"paper": {"simulated": True}, "testnet": {"testnet": True}, "live": {"testnet": False}},
    "kraken":      {"paper": {"simulated": True}, "live": {}},
    "ibkr":        {"paper": {"paper": True}, "live": {"paper": False}},
    "polymarket":  {"paper": {"simulated": True}, "live": {}},
}

def build_adapter(exchange: str, mode: str, key: str, secret: str,
                  passphrase: str | None = None) -> AdapterSpec:
    """Build adapter spec for given exchange + mode.

    Args:
        exchange: Exchange ID (binance, bybit, etc.)
        mode: paper | testnet | demo | live
        key: API key (decrypted from vault)
        secret: API secret (decrypted from vault)
        passphrase: Optional passphrase (OKX, Coinbase, etc.)
    """
    if mode == "paper":
        # SimulatedExchange — real market data, fake wallet
        return AdapterSpec(exchange, mode,
            data_client={"venue": exchange.upper(), "live": True, "simulated": True},
            exec_client={"venue": exchange.upper(), "simulated": True})

    base = BASE.get(exchange, {}).get(mode)
    if base is None:
        raise ValueError(f"unsupported: {exchange}/{mode}")

    cfg = {"api_key": key, "api_secret": secret, **base}
    if passphrase:
        cfg["api_passphrase"] = passphrase

    return AdapterSpec(exchange, mode, data_client=cfg, exec_client=cfg)
