from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    database_url: str
    redis_url: str
    encryption_key: str
    exec_log_level: str = "INFO"

settings = Settings()  # type: ignore[call-arg]
