"""Execution engine — consumes commands, drives Nautilus live node, publishes events.

NautilusTrader TradingNode integration:
  - https://nautilustrader.io/docs/nightly/getting_started/core_concepts/
  - https://nautilustrader.io/docs/nightly/integrations/binance/

Architecture:
  1. Load exchange accounts from DB (decrypt keys)
  2. Build Nautilus TradingNode per account
  3. Consume commands from Redis Stream → submit orders
  4. Publish events (order, fill, position, pnl) back to Redis Stream
  5. Heartbeat every 5s
"""
import asyncio, msgpack, time, uuid, signal as sig
from typing import Any
import asyncpg, redis.asyncio as redis
import structlog

from .config import settings
from .keyvault import decrypt
from .adapters import build_adapter

log = structlog.get_logger()

S_EVENTS = "nexus:events"
S_COMMANDS = "nexus:commands"

class ExecutionEngine:
    def __init__(self) -> None:
        self.pg: asyncpg.Pool | None = None
        self.rd: redis.Redis | None = None
        self.nodes: dict[str, Any] = {}      # acct_id -> TradingNode
        self.stop = asyncio.Event()

    async def start(self) -> None:
        """Initialize DB, Redis, load accounts, start loops."""
        self.pg = await asyncpg.create_pool(settings.database_url, min_size=1, max_size=4)
        self.rd = redis.from_url(settings.redis_url, decode_responses=False)
        await self.rd.ping()
        await self.load_accounts()
        await asyncio.gather(self.command_loop(), self.heartbeat())

    async def stop(self) -> None:
        self.stop.set()
        # Stop all TradingNodes
        for acct_id, node in self.nodes.items():
            try:
                # Nautilus node teardown
                if hasattr(node, 'stop'):
                    node.stop()
                log.info("node.stopped", acct=acct_id)
            except Exception as e:
                log.error("node.stop_fail", acct=acct_id, err=str(e))
        if self.rd:
            await self.rd.aclose()
        if self.pg:
            await self.pg.close()

    async def load_accounts(self) -> None:
        """Load active exchange accounts from DB and build Nautilus nodes."""
        assert self.pg
        async with self.pg.acquire() as c:
            rows = await c.fetch(
                "SELECT id, exchange, mode, api_key_enc, api_secret_enc, passphrase_enc "
                "FROM exchange_accounts WHERE is_active = true")

        for r in rows:
            try:
                spec = build_adapter(
                    r["exchange"], r["mode"],
                    decrypt(r["api_key_enc"]),
                    decrypt(r["api_secret_enc"]),
                    decrypt(r["passphrase_enc"]) if r["passphrase_enc"] else None,
                )
                # Build Nautilus TradingNode (simplified — full build in production)
                node = self._build_node(spec)
                self.nodes[str(r["id"])] = node
                log.info("node.loaded", acct=str(r["id"]),
                         exchange=r["exchange"], mode=r["mode"])
            except Exception as e:
                log.error("node.load_fail", acct=str(r["id"]), err=str(e))

    def _build_node(self, spec: Any) -> Any:
        """Build Nautilus TradingNode from adapter spec.

        Full implementation wires:
          - TradingNodeConfig with data_clients + exec_clients
          - BinanceLiveDataClientFactory + BinanceLiveExecClientFactory
          - Strategy registration
          - Event handlers → Redis publish
        """
        # Placeholder: return spec dict for now
        # Full Nautilus integration in production deployment
        from types import SimpleNamespace
        return SimpleNamespace(spec=spec, stop=lambda: None)

    async def publish(self, event: dict) -> None:
        """Publish event to Redis Stream with engine timestamp."""
        assert self.rd
        event["engine_ts"] = int(time.time() * 1e9)
        await self.rd.xadd(S_EVENTS, {b"d": msgpack.packb(event)},
                           maxlen=50000, approximate=True)

    async def command_loop(self) -> None:
        """Consume commands from Redis Stream and execute."""
        assert self.rd
        last_id = "$"
        while not self.stop.is_set():
            try:
                res = await self.rd.xread({S_COMMANDS: last_id}, block=1000, count=100)
            except Exception as e:
                log.error("xread.fail", err=str(e))
                await asyncio.sleep(1)
                continue
            if not res:
                continue
            for _, entries in res:
                for eid, fields in entries:
                    last_id = eid
                    try:
                        cmd = msgpack.unpackb(fields[b"d"], raw=False)
                        await self.handle(cmd)
                    except Exception as e:
                        log.error("cmd.fail", err=str(e))

    async def handle(self, cmd: dict) -> None:
        """Route command to appropriate handler."""
        c = cmd.get("c")
        log.info("cmd", c=c, user=cmd.get("user"))
        if c == "place_order":
            await self.place_order(cmd)
        elif c == "cancel_order":
            await self.cancel_order(cmd)
        elif c == "kill_switch":
            await self.kill(cmd)
        elif c == "strategy_toggle":
            await self.publish({"t": "strategy_toggled", **cmd})
        else:
            log.warning("cmd.unknown", c=c)

    async def place_order(self, cmd: dict) -> None:
        """Place order — emit order event, Nautilus submission in production."""
        oid = uuid.uuid4().hex
        await self.publish({
            "t": "order", "id": oid, "client_id": oid,
            "ex": cmd["ex"], "sym": cmd["sym"], "side": cmd["side"],
            "type": cmd["type"], "qty": cmd["qty"],
            "px": cmd.get("px"), "tif": cmd.get("tif", "gtc"),
            "status": "submitted", "filled_qty": 0,
            "ts": int(time.time() * 1e9),
        })
        # Production: node.submit_order(order) via Nautilus API

    async def cancel_order(self, cmd: dict) -> None:
        """Cancel order — emit canceled event."""
        await self.publish({
            "t": "order", "id": cmd["order_id"],
            "client_id": cmd["order_id"], "ex": cmd["ex"],
            "sym": "", "side": "buy", "type": "limit",
            "qty": 0, "tif": "gtc", "status": "canceled",
            "filled_qty": 0, "ts": int(time.time() * 1e9)
        })

    async def kill(self, cmd: dict) -> None:
        """Emergency kill switch — cancel all orders, close positions."""
        scope = cmd.get("scope", "all")
        target = cmd.get("target")
        log.warning("kill_switch", scope=scope, target=target)
        # Production: node.cancel_all_orders() + position close
        await self.publish({
            "t": "kill", "scope": scope, "target": target,
            "ts": int(time.time() * 1e9)
        })

    async def heartbeat(self) -> None:
        """Periodic heartbeat with node status."""
        while not self.stop.is_set():
            await self.publish({
                "t": "heartbeat", "service": "execution",
                "nodes": len(self.nodes),
                "ts": int(time.time() * 1e9)
            })
            await asyncio.sleep(5)
