import base64
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from .config import settings

def _key() -> bytes:
    return base64.b64decode(settings.encryption_key)

def decrypt(blob: bytes) -> str:
    nonce, ct = blob[:12], blob[12:]
    return AESGCM(_key()).decrypt(nonce, ct, None).decode()
