"""Nexus Execution — NautilusTrader LiveNode wrapper."""
__version__ = "0.1.0"
