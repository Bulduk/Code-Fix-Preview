import asyncio, signal as sig
import structlog
from .engine import ExecutionEngine

log = structlog.get_logger()

async def amain() -> None:
    eng = ExecutionEngine()
    loop = asyncio.get_running_loop()
    for s in (sig.SIGINT, sig.SIGTERM):
        loop.add_signal_handler(s, lambda: asyncio.create_task(eng.stop()))
    log.info("execution.start")
    try:
        await eng.start()
    finally:
        await eng.stop()
        log.info("execution.stop")

if __name__ == "__main__":
    asyncio.run(amain())
