use wasm_bindgen::prelude::*;

/// Hızlı PnL formatlayıcı — UI'da büyük tablo render'ında kullanılacak.
#[wasm_bindgen]
pub fn format_pnl(value: f64) -> String {
    if value >= 0.0 { format!("+{:.2}", value) } else { format!("{:.2}", value) }
}

#[wasm_bindgen]
pub fn pct_change(prev: f64, curr: f64) -> f64 {
    if prev == 0.0 { 0.0 } else { (curr - prev) / prev * 100.0 }
}
