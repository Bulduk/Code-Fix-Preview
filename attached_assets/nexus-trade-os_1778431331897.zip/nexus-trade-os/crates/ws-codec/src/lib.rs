//! MsgPack codec for Nexus Trade OS engine events & commands.
//! Mirrors packages/proto/src/index.ts schema.

use serde::{Deserialize, Serialize};
use thiserror::Error;

#[derive(Debug, Error)]
pub enum CodecError {
    #[error("encode: {0}")] Encode(String),
    #[error("decode: {0}")] Decode(String),
}

#[derive(Debug, Serialize, Deserialize)]
#[serde(tag = "t")]
pub enum Event {
    #[serde(rename = "tick")]
    Tick { ex: String, sym: String, px: f64, qty: f64, side: String, ts: i64 },
    #[serde(rename = "bar")]
    Bar { ex: String, sym: String, tf: String,
          o: f64, h: f64, l: f64, c: f64, v: f64, ts: i64 },
    #[serde(rename = "signal")]
    Signal { id: String, strategy: String, ex: String, sym: String,
             side: String, strength: f64, reason: String, ts: i64 },
    #[serde(rename = "order")]
    Order { id: String, client_id: String, ex: String, sym: String,
            side: String, #[serde(rename = "type")] otype: String,
            qty: f64, px: Option<f64>, tif: String, status: String,
            filled_qty: f64, avg_px: Option<f64>, ts: i64 },
    #[serde(rename = "fill")]
    Fill { order_id: String, ex: String, sym: String, side: String,
           qty: f64, px: f64, fee: f64, fee_ccy: String, ts: i64 },
    #[serde(rename = "pnl")]
    Pnl { account: String, equity: f64, realized: f64, unrealized: f64, ts: i64 },
    #[serde(other)]
    Other,
}

pub fn encode(ev: &Event) -> Result<Vec<u8>, CodecError> {
    rmp_serde::to_vec_named(ev).map_err(|e| CodecError::Encode(e.to_string()))
}

pub fn decode(buf: &[u8]) -> Result<Event, CodecError> {
    rmp_serde::from_slice(buf).map_err(|e| CodecError::Decode(e.to_string()))
}

#[cfg(feature = "python")]
mod py {
    use super::*;
    use pyo3::prelude::*;
    use pyo3::types::PyBytes;

    #[pyfunction]
    fn encode_event(py: Python<'_>, json: &str) -> PyResult<Py<PyBytes>> {
        let ev: Event = serde_json::from_str(json)
            .map_err(|e| pyo3::exceptions::PyValueError::new_err(e.to_string()))?;
        let b = encode(&ev).map_err(|e| pyo3::exceptions::PyValueError::new_err(e.to_string()))?;
        Ok(PyBytes::new_bound(py, &b).into())
    }

    #[pyfunction]
    fn decode_event(buf: &[u8]) -> PyResult<String> {
        let ev = decode(buf).map_err(|e| pyo3::exceptions::PyValueError::new_err(e.to_string()))?;
        serde_json::to_string(&ev).map_err(|e| pyo3::exceptions::PyValueError::new_err(e.to_string()))
    }

    #[pymodule]
    fn nexus_ws_codec(m: &Bound<'_, PyModule>) -> PyResult<()> {
        m.add_function(wrap_pyfunction!(encode_event, m)?)?;
        m.add_function(wrap_pyfunction!(decode_event, m)?)?;
        Ok(())
    }
}
