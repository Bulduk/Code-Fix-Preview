use pyo3::prelude::*;

/// Exponential moving average — O(n), allocation-free.
#[pyfunction]
fn ema(values: Vec<f64>, period: usize) -> Vec<f64> {
    if values.is_empty() || period == 0 { return vec![]; }
    let k = 2.0 / (period as f64 + 1.0);
    let mut out = Vec::with_capacity(values.len());
    let mut prev = values[0];
    out.push(prev);
    for &v in &values[1..] {
        prev = v * k + prev * (1.0 - k);
        out.push(prev);
    }
    out
}

#[pyfunction]
fn rsi(values: Vec<f64>, period: usize) -> Vec<f64> {
    let n = values.len();
    let mut out = vec![f64::NAN; n];
    if n <= period { return out; }
    let (mut gain, mut loss) = (0.0f64, 0.0f64);
    for i in 1..=period {
        let d = values[i] - values[i-1];
        if d >= 0.0 { gain += d; } else { loss -= d; }
    }
    gain /= period as f64; loss /= period as f64;
    out[period] = if loss == 0.0 { 100.0 } else { 100.0 - 100.0 / (1.0 + gain / loss) };
    for i in (period+1)..n {
        let d = values[i] - values[i-1];
        let (g, l) = if d >= 0.0 { (d, 0.0) } else { (0.0, -d) };
        gain = (gain * (period as f64 - 1.0) + g) / period as f64;
        loss = (loss * (period as f64 - 1.0) + l) / period as f64;
        out[i] = if loss == 0.0 { 100.0 } else { 100.0 - 100.0 / (1.0 + gain / loss) };
    }
    out
}

/// Orderbook microprice (scalping anchor).
#[pyfunction]
fn microprice(bid: f64, ask: f64, bid_qty: f64, ask_qty: f64) -> f64 {
    let s = bid_qty + ask_qty;
    if s <= 0.0 { return (bid + ask) * 0.5; }
    (bid * ask_qty + ask * bid_qty) / s
}

#[pymodule]
fn nexushotindicators(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(ema, m)?)?;
    m.add_function(wrap_pyfunction!(rsi, m)?)?;
    m.add_function(wrap_pyfunction!(microprice, m)?)?;
    Ok(())
}
