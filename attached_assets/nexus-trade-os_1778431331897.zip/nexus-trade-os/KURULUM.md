# Nexus Trade OS — Kurulum Kılavuzu

## Sistem Gereksinimleri

| Bileşen | Minimum | Önerilen |
|---------|---------|----------|
| CPU | 2 vCPU | 4 vCPU |
| RAM | 8 GB | 16 GB |
| Disk | 40 GB SSD | 100 GB SSD |
| OS | Ubuntu 24.04 LTS | Ubuntu 24.04 LTS |
| Network | 100 Mbps | 1 Gbps |

## Hızlı Başlangıç (Tek Komut)

```bash
# 1. ZIP'i aç
cd /opt
sudo unzip nexus-trade-os.zip

# 2. VPS hazırla (root olarak)
cd nexus-trade-os
sudo ./scripts/vps-install.sh

# 3. Sistemi başlat
./scripts/bootstrap.sh
```

## Manuel Kurulum Adım Adım

### 1. VPS Hazırlığı

```bash
# Root yetkisi
sudo -i

# Sistem güncelle
apt update && apt upgrade -y

# Gerekli paketler
apt install -y curl git make unzip fail2ban ufw

# Docker kur
install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
chmod a+r /etc/apt/keyrings/docker.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "$VERSION_CODENAME") stable" > /etc/apt/sources.list.d/docker.list
apt update
apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# Swap (8GB RAM için 4GB)
fallocate -l 4G /swapfile
chmod 600 /swapfile
mkswap /swapfile
swapon /swapfile
echo "/swapfile none swap sw 0 0" >> /etc/fstab
sysctl vm.swappiness=10

# Firewall
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable

# Servisleri başlat
systemctl enable --now docker fail2ban
```

### 2. Ortam Değişkenleri

```bash
cd nexus-trade-os/ops
cp .env.example .env

# Secret'ları otomatik üret
JWT=$(openssl rand -hex 32)
ENC=$(openssl rand -base64 32)
RPW=$(openssl rand -hex 16)
PPW=$(openssl rand -hex 16)
GPW=$(openssl rand -hex 12)

sed -i "s/generate_with_openssl_rand_hex_32/$JWT/g" .env
sed -i "s/generate_with_openssl_rand_base64_32/$ENC/g" .env
sed -i "s/change_me_redis_pw/$RPW/g" .env
sed -i "s/change_me_strong_pw/$PPW/g" .env
sed -i "s/change_me_grafana/$GPW/g" .env

# Domain ayarla (production için)
sed -i "s/localhost/your-domain.com/g" .env
```

### 3. İlk Admin Parolası

```bash
# Varsayılan: admin@nexus.local / change-me-immediately
# İlk girişte değiştir!
```

### 4. Docker Compose Başlat

```bash
cd nexus-trade-os/ops
docker compose pull
docker compose build
docker compose up -d

# Durum kontrolü
docker compose ps
docker compose logs -f --tail=100
```

### 5. Erişim Noktaları

| Servis | URL | Varsayılan |
|--------|-----|-----------|
| UI | https://your-domain.com | admin@nexus.local |
| Gateway API | https://your-domain.com/api/health | - |
| Grafana | https://your-domain.com:3001 | admin / auto-generated |
| Prometheus | http://localhost:9090 | - |

## Mimari Özeti

```
┌─────────────────────────────────────────────────────────────┐
│  NEXUS UI (Next.js 15 + TS + Tailwind + shadcn)            │
│  FAB menu · Bottom nav · Detail modals · ⌘K komut paleti   │
│  WebSocket MsgPack binary · Rust→WASM PnL render           │
└────────────────────┬────────────────────────────────────────┘
                     │ WS + REST
┌────────────────────▼────────────────────────────────────────┐
│  GATEWAY (FastAPI + uvloop + JWT + RBAC + Audit)           │
│  AES-GCM API key vault · MsgPack codec · Prometheus        │
└────┬──────────────┬──────────────┬──────────────┬─────────┘
     │              │              │              │
┌────▼─────┐ ┌──────▼──────┐ ┌─────▼─────────┐ ┌──▼──────────┐
│ SIGNAL   │ │ EXECUTION   │ │ AGENT         │ │ REGIME      │
│ ENGINE   │ │ NAUTILUS    │ │ RUNTIME       │ │ ENGINE      │
│ Py+Rust  │ │ LiveNode    │ │ Rust+LLM      │ │ Otomatik    │
│          │ │ Binance etc │ │ köprüsü       │ │ strateji    │
└────┬─────┘ └──────┬──────┘ └─────┬─────────┘ └──┬──────────┘
     │              │              │              │
┌────▼──────────────▼──────────────▼──────────────▼────────────┐
│  EVENT BUS: Redis Streams (ms latency)                     │
└────┬─────────────────────────────────────────────────────────┘
     │
┌────▼─────────────────────────────────────────────────────────┐
│  TimescaleDB 2.17 (PnL/sinyal time-series)                │
│  + Redis (state/cache)                                     │
│  + Parquet/CSV export · retention policy · compression      │
└─────────────────────────────────────────────────────────────┘
```

## Desteklenen Borsalar

| Borsa | Spot | Futures | Options | Paper | Testnet | Live |
|-------|------|---------|---------|-------|---------|------|
| Binance | ✅ | ✅ (USDT-M) | - | ✅ | ✅ | ✅ |
| Bybit | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| OKX | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Coinbase | ✅ | ✅ (perps) | - | ✅ | ✅ | ✅ |
| Kraken | ✅ | ✅ | - | ✅ | - | ✅ |
| Bitmex | - | ✅ | - | ✅ | ✅ | ✅ |
| dYdX v4 | - | ✅ | - | ✅ | ✅ | ✅ |
| Hyperliquid | ✅ | ✅ | - | ✅ | ✅ | ✅ |
| IBKR | ✅ | ✅ | ✅ | ✅ | - | ✅ |
| Polymarket | ✅ | - | - | ✅ | - | ✅ |

## Strateji Kütüphanesi

1. **Scalping** — Orderbook imbalance + microprice
2. **Mean Reversion** — Bollinger + z-score
3. **Momentum** — EMA cross
4. **Breakout** — Donchian channel
5. **Grid** — Geometric/arithmetic
6. **Market Making** — Avellaneda-Stoikov
7. **DCA** — Periodic dollar-cost averaging
8. **Trend Following** — Donchian + ATR trail
9. **Arbitrage** — Cross-exchange edge

## Ajan Sistemi

- **LLM Sağlayıcılar**: Anthropic Claude, OpenAI GPT-4o/o1, Ollama (yerel)
- **Sistem Talimatı**: Her ajan için özel system prompt
- **Prompt Versiyonlama**: Ajan başına ayrı prompt alanı
- **Tool Ekleme**: Admin panelden OpenAPI/JSON schema yükleme
- **API Ekleme**: Harici REST API'leri ajan araçları olarak tanımlama

## PnL Yönetimi

- **Canlı Takip**: Realized + unrealized, per-strategy, per-symbol
- **Export**: CSV / JSON formatında dosya indirme
- **Retention**: UI'dan kayıt saklama süresi ayarı (gün)
- **Temizleme**: Eski kayıtları otomatik/doğrudan silme
- **TimescaleDB**: Otomatik compression + retention policy

## Admin Paneli

- **Borsalar**: Hesap ekle/sil, paper/testnet/live mod, API key yönetimi
- **Stratejiler**: Aç/kapat, parametre hot-reload, allokasyon
- **Ajanlar**: LLM seçimi, prompt edit, tool yönetimi, bütçe
- **Kullanıcılar**: RBAC (admin/trader/viewer), 2FA, IP whitelist
- **Audit Log**: Immutable kayıt, her admin aksiyonu izlenir
- **Risk**: Max drawdown, position size, daily loss limit, leverage cap

## Komut Paleti (⌘K)

```
"btc long 0.1 scalping" → Hızlı emir
"ajan pnl raporu"       → Ajan çağır
"borsa ekle binance"    → Yönlendirme
"pnl export"            → PnL sayfası
```

## Monitoring

- **Prometheus**: Metrik toplama
- **Grafana**: Dashboard görselleştirme
- **Gateway /metrics**: FastAPI native metrics
- **Log aggregation**: Docker json-file driver

## Troubleshooting

```bash
# Servis logları
docker compose logs -f gateway
docker compose logs -f execution
docker compose logs -f signal-engine

# Redis kontrol
docker compose exec redis redis-cli -a $REDIS_PASSWORD ping

# DB kontrol
docker compose exec timescale pg_isready -U nexus

# Sıfırlama (DİKKAT: veri silinir!)
docker compose down -v
docker compose up -d
```

## Güvenlik Kontrol Listesi

- [ ] `.env` dosyası git'e eklenmemiş
- [ ] JWT secret 32+ byte random
- [ ] AES-GCM encryption key 32 byte base64
- [ ] İlk admin parolası değiştirilmiş
- [ ] 2FA aktif (opsiyonel ama önerilir)
- [ ] Firewall sadece 22/80/443 açık
- [ ] Fail2ban aktif
- [ ] API key'ler vault'ta AES-GCM ile şifreli
- [ ] Testnet ile başla, live sonradan aç

## Geliştirme

```bash
# Local development (without Docker)
cd apps/ui && pnpm install && pnpm dev
cd apps/gateway && uv run python -m nexusgateway
cd services/signal-engine && uv run python -m nexussignal

# Rust crate build
cd crates/hot-indicators
maturin develop --release

# Test
cd apps/gateway && pytest
cd services/signal-engine && pytest
```

## Lisans

Proprietary — Ticari kullanım için lisans gerekir.

---

**Nexus Trade OS v0.1.0** | Multi-exchange · Rust-native · AI-augmented
