
export default function Home() {
  return <div style={{padding:40,fontFamily:'sans-serif'}}>
    <h1>Nexus Trade OS</h1>
    <p>Gateway + UI scaffold ready.</p>
  </div>
}
